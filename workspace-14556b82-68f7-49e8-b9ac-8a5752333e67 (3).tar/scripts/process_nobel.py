"""
Nobel Prize dashboard data pipeline.
Source: official Nobel Prize API 2.1 (/laureates?limit=1200)
Cleans + derives features exactly like the uploaded notebook:
  - org laureates -> gender 'Organization', names filled from orgName
  - Age = awardYear - birth year
  - Decade = (awardYear // 10) * 10
  - portion tiers 1/1, 1/2, 1/3
  - birth_countryNow vs affiliation country (brain drain analysis)
Then computes every aggregate the dashboard needs and writes src/data/nobel.json
"""
import json
from collections import defaultdict, Counter
from statistics import median

RAW = "/home/z/my-project/scripts/nobel_raw.json"
OUT = "/home/z/my-project/src/data/nobel.json"


def en(d):
    if d is None:
        return None
    if isinstance(d, dict):
        return d.get("en")
    return d


import re

COUNTRY_DISPLAY = {
    "USA": "United States",
    "United Kingdom": "United Kingdom",
    "Russia": "Russia",
    "Czech Republic": "Czechia",
    "Republic of Korea": "South Korea",
    "Korea (South)": "South Korea",
}


def clean_country(c):
    if not c:
        return None
    return COUNTRY_DISPLAY.get(c, c)


def clean_inst(name):
    if not name:
        return None
    n = name.strip()
    n = re.sub(r"\bUniv\.\s*", "University ", n)
    n = re.sub(r"\bInst\.\s*", "Institute ", n)
    n = re.sub(r"\bCalif\.\s*", "California ", n)
    n = re.sub(r"\bMass\.\s*", "Massachusetts ", n)
    n = re.sub(r"\bColl\.\s*", "College ", n)
    n = re.sub(r"\bHosp\.\s*", "Hospital ", n)
    n = re.sub(r"\s+", " ", n).strip()
    # merge common variants
    variants = {
        "California University": "University of California",
        "Johns Hopkins University": "Johns Hopkins University",
        "Johns Hopkins Univ.": "Johns Hopkins University",
        "Johns Hopkins School of Medicine": "Johns Hopkins University",
        "Johns Hopkins University School of Medicine": "Johns Hopkins University",
        "Harvard Medical School": "Harvard University",
        "Harvard Business School": "Harvard University",
        "Harvard University": "Harvard University",
        "Harvard Univ.": "Harvard University",
        "Harvard University, Cambridge, MA": "Harvard University",
        "Massachusetts Institute of Technology (MIT)": "MIT",
        "Massachusetts Institute of Technology, Cambridge, MA": "MIT",
        "MIT, Cambridge, MA": "MIT",
        "California Institute of Technology (Caltech)": "Caltech",
        "California Institute of Technology (Caltech), Pasadena, CA": "Caltech",
        "California Institute of Technology": "Caltech",
        "University of California, Berkeley": "UC Berkeley",
        "University of California, Berkeley, CA": "UC Berkeley",
        "University of California, San Diego": "UC San Diego",
        "University of California, San Diego, CA": "UC San Diego",
        "University of California, Santa Barbara": "UC Santa Barbara",
        "University of California, Los Angeles": "UCLA",
        "University of California, Los Angeles, CA": "UCLA",
        "Rockefeller Institute for Medical Research": "Rockefeller University",
        "Rockefeller University": "Rockefeller University",
        "University of Chicago, Chicago, IL": "University of Chicago",
        "Columbia University, New York, NY": "Columbia University",
        "Princeton University, Princeton, NJ": "Princeton University",
        "Stanford University, Stanford, CA": "Stanford University",
        "Cornell University, Ithaca, NY": "Cornell University",
        "Yale University, New Haven, CT": "Yale University",
        "University of Cambridge, Cambridge, United Kingdom": "University of Cambridge",
        "Cambridge University": "University of Cambridge",
        "MRC Laboratory of Molecular Biology, Cambridge, United Kingdom": "MRC Laboratory of Molecular Biology",
        "University of Oxford, Oxford, United Kingdom": "University of Oxford",
        "Oxford University": "University of Oxford",
        "Max Planck Institute": "Max Planck Institutes",
        "Bell Telephone Laboratories": "Bell Labs",
        "Bell Laboratories": "Bell Labs",
        "Bell Labs, Murray Hill, NJ": "Bell Labs",
        "AT&T Bell Laboratories": "Bell Labs",
        "National Institute of Standards and Technology": "NIST",
        "National Bureau of Standards": "NIST",
        "CERN, Geneva, Switzerland": "CERN",
        "European Organization for Nuclear Research (CERN)": "CERN",
        "IBM Thomas J. Watson Research Center": "IBM",
        "Watson Scientific Computing Laboratory": "IBM",
        "Institute for Advanced Study, Princeton, NJ": "Institute for Advanced Study",
        "Washington University, St. Louis": "Washington University in St. Louis",
        "University College London": "University College London",
        "University College, London": "University College London",
        "Kaiser-Wilhelm-Institut": "Kaiser-Wilhelm Institutes",
    }
    return variants.get(n, n)


records = []
data = json.load(open(RAW))
laureates = data["laureates"]

for l in laureates:
    lid = l["id"]
    gender = l.get("gender")  # male | female | None(org)
    is_org = gender is None
    name = en(l.get("knownName")) or en(l.get("orgName")) or en(l.get("fullName"))
    if is_org:
        name = en(l.get("orgName")) or name
        disp_gender = "Organization"
    else:
        disp_gender = gender.capitalize()
    birth = l.get("birth") or {}
    birth_year = birth.get("year")
    birth_year = int(birth_year) if birth_year else None
    birth_place = birth.get("place") or {}
    death = l.get("death") or {}
    for p in l.get("nobelPrizes", []):
        year = int(p["awardYear"])
        cat = en(p.get("category"))
        raw_portion = (p.get("portion") or "1/1").strip()
        if raw_portion in ("", "1", "1/1"):
            portion = "1/1"
        else:
            portion = raw_portion  # 1/2 | 1/3 | 1/4
        affs = p.get("affiliations") or []
        aff1 = affs[0] if affs else {}
        aff_name = clean_inst(en(aff1.get("nameNow")) or en(aff1.get("name")))
        aff_country = en(aff1.get("countryNow")) or en(aff1.get("country"))
        aff_city = en(aff1.get("cityNow")) or en(aff1.get("city"))
        age = (year - birth_year) if birth_year else None
        rec = {
            "id": int(lid),
            "name": name,
            "gender": disp_gender,
            "indOrOrg": "Organization" if is_org else "Individual",
            "year": year,
            "category": cat,
            "categoryFullName": en(p.get("categoryFullName")),
            "portion": portion,
            "prizeAmount": p.get("prizeAmount"),
            "prizeAmountAdjusted": p.get("prizeAmountAdjusted"),
            "dateAwarded": p.get("dateAwarded"),
            "motivation": (en(p.get("motivation")) or "").strip(),
            "birthYear": birth_year,
            "birthCountry": clean_country(en(birth_place.get("countryNow")) or en(birth_place.get("country"))),
            "birthCity": en(birth_place.get("cityNow")) or en(birth_place.get("city")),
            "birthContinent": en(birth_place.get("continent")),
            "deathYear": int(death["year"]) if death.get("year") else None,
            "affiliation": aff_name,
            "affiliationCountry": clean_country(aff_country),
            "affiliationCity": aff_city,
            "age": age,
            "decade": (year // 10) * 10,
            "laureateUrl": f"https://www.nobelprize.org/laureate/{lid}",
        }
        records.append(rec)

records.sort(key=lambda r: (-r["year"], r["category"], r["name"]))

# ---------------- aggregates ----------------
CAT_ORDER = ["Physics", "Chemistry", "Physiology or Medicine", "Literature", "Peace", "Economic Sciences"]
CAT_SHORT = {"Physiology or Medicine": "Medicine", "Economic Sciences": "Economics"}

# 1. KPIs
uniq = {r["id"] for r in records}
inds = [r for r in records if r["indOrOrg"] == "Individual"]
orgs = [r for r in records if r["indOrOrg"] == "Organization"]
females = [r for r in inds if r["gender"] == "Female"]
males = [r for r in inds if r["gender"] == "Male"]
ages = [r["age"] for r in inds if r["age"] is not None]
countries = {r["birthCountry"] for r in records if r["birthCountry"]}
kpis = {
    "totalLaureates": len(uniq),
    "totalPrizeRecords": len(records),
    "femaleLaureates": len({r["id"] for r in females}),
    "femaleShare": round(100 * len({r["id"] for r in females}) / len(uniq), 1),
    "orgLaureates": len({r["id"] for r in orgs}),
    "countries": len(countries),
    "avgAge": round(sum(ages) / len(ages), 1),
    "youngest": min(ages),
    "oldest": max(ages),
    "yearMin": min(r["year"] for r in records),
    "yearMax": max(r["year"] for r in records),
    "categories": sorted(set(r["category"] for r in records)),
    "repeatLaureates": len(uniq) - len({r["id"] for r in records}) ,  # placeholder, recompute below
}
cnt_by_id = Counter(r["id"] for r in records)
kpis["repeatLaureates"] = sum(1 for v in cnt_by_id.values() if v > 1)

# 2. awards per year
by_year = Counter(r["year"] for r in records)
by_year_list = [{"year": y, "laureates": by_year.get(y, 0)} for y in range(1901, max(by_year) + 1)]

# 3. by category + gender split
cat_gender = defaultdict(Counter)
for r in records:
    cat_gender[r["category"]][r["gender"]] += 1
by_category = [
    {
        "category": c,
        "short": CAT_SHORT.get(c, c),
        "total": sum(cat_gender[c].values()),
        "Male": cat_gender[c]["Male"],
        "Female": cat_gender[c]["Female"],
        "Organization": cat_gender[c]["Organization"],
    }
    for c in CAT_ORDER
]

# 4. age stats by category
age_by_cat = defaultdict(list)
for r in inds:
    if r["age"] is not None:
        age_by_cat[r["category"]].append(r["age"])
age_by_category = []
for c in CAT_ORDER:
    a = sorted(age_by_cat[c])
    if not a:
        continue
    age_by_category.append({
        "category": CAT_SHORT.get(c, c),
        "mean": round(sum(a) / len(a), 1),
        "median": round(median(a), 1),
        "min": a[0],
        "max": a[-1],
        "count": len(a),
    })

# 5. age trend by decade (mean/median)
age_by_decade_map = defaultdict(list)
for r in inds:
    if r["age"] is not None:
        age_by_decade_map[r["decade"]].append(r["age"])
age_by_decade = []
for d in sorted(age_by_decade_map):
    a = age_by_decade_map[d]
    age_by_decade.append({"decade": str(d), "mean": round(sum(a) / len(a), 1), "median": round(median(a), 1), "n": len(a)})

# 6. country x category (top 10 birth countries)
cc = defaultdict(Counter)
country_totals = Counter()
for r in records:
    bc = r["birthCountry"]
    if not bc:
        continue
    country_totals[bc] += 1
    cc[bc][r["category"]] += 1
top_countries = [c for c, _ in country_totals.most_common(10)]
country_by_category = {
    "countries": top_countries,
    "categories": [CAT_SHORT.get(c, c) for c in CAT_ORDER],
    "matrix": [[cc[c][cat] for cat in CAT_ORDER] for c in top_countries],
    "rowTotals": [country_totals[c] for c in top_countries],
}

# 7. country x decade (top 8)
cd = defaultdict(Counter)
for r in records:
    bc = r["birthCountry"]
    if not bc:
        continue
    cd[bc][r["decade"]] += 1
top_c8 = [c for c, _ in country_totals.most_common(8)]
decades_all = sorted(set(r["decade"] for r in records))
country_by_decade = {
    "countries": top_c8,
    "decades": [str(d) for d in decades_all],
    "matrix": [[cd[c][d] for d in decades_all] for c in top_c8],
}

# 8. top institutions (affiliation_1, cleaned)
inst = Counter()
for r in records:
    if r["affiliation"]:
        inst[r["affiliation"]] += 1
top_institutions = [{"name": n, "count": c} for n, c in inst.most_common(15)]

# 9. share dilution by decade
share_by_decade = defaultdict(Counter)
for r in records:
    p = r["portion"]
    tier = {"1/1": "full", "1/2": "half", "1/3": "third", "1/4": "quarter"}.get(p)
    if tier:
        share_by_decade[r["decade"]][tier] += 1
share_by_decade_list = [
    {
        "decade": str(d),
        "full": share_by_decade[d]["full"],
        "half": share_by_decade[d]["half"],
        "third": share_by_decade[d]["third"],
        "quarter": share_by_decade[d]["quarter"],
        "total": sum(share_by_decade[d].values()),
    }
    for d in sorted(share_by_decade)
]

# 10. migrant vs domestic by decade (individuals w/ birth country + affiliation country)
mig_by_decade = defaultdict(Counter)
for r in inds:
    if r["birthCountry"] and r["affiliationCountry"]:
        key = "migrant" if r["birthCountry"] != r["affiliationCountry"] else "domestic"
        mig_by_decade[r["decade"]][key] += 1
migration_by_decade = [
    {
        "decade": str(d),
        "domestic": mig_by_decade[d]["domestic"],
        "migrant": mig_by_decade[d]["migrant"],
        "migrantPct": round(100 * mig_by_decade[d]["migrant"] / max(1, mig_by_decade[d]["migrant"] + mig_by_decade[d]["domestic"]), 1),
    }
    for d in sorted(mig_by_decade)
]

# 11. top migration flows birth -> affiliation
flows = Counter()
for r in inds:
    if r["birthCountry"] and r["affiliationCountry"] and r["birthCountry"] != r["affiliationCountry"]:
        flows[(r["birthCountry"], r["affiliationCountry"])] += 1
top_flows = [{"from": f, "to": t, "count": c} for (f, t), c in flows.most_common(12)]

# 12. female share by decade
fem_by_decade = defaultdict(Counter)
for r in records:
    fem_by_decade[r["decade"]][r["gender"]] += 1
female_by_decade = [
    {
        "decade": str(d),
        "female": fem_by_decade[d]["Female"],
        "male": fem_by_decade[d]["Male"],
        "org": fem_by_decade[d]["Organization"],
        "total": sum(fem_by_decade[d].values()),
        "femalePct": round(100 * fem_by_decade[d]["Female"] / sum(fem_by_decade[d].values()), 1),
    }
    for d in sorted(fem_by_decade)
]

# 13. youngest / oldest laureates ever (fun facts)
young = sorted([r for r in inds if r["age"] is not None], key=lambda r: r["age"])[:5]
old = sorted([r for r in inds if r["age"] is not None], key=lambda r: -r["age"])[:5]
fun_facts = {
    "youngest": [{"name": r["name"], "age": r["age"], "year": r["year"], "category": r["category"]} for r in young],
    "oldest": [{"name": r["name"], "age": r["age"], "year": r["year"], "category": r["category"]} for r in old],
    "topFlow": top_flows[0] if top_flows else None,
    "topInstitution": {"name": top_institutions[0]["name"], "count": top_institutions[0]["count"]} if top_institutions else None,
}

out = {
    "kpis": kpis,
    "byYear": by_year_list,
    "byCategory": by_category,
    "ageByCategory": age_by_category,
    "ageByDecade": age_by_decade,
    "countryByCategory": country_by_category,
    "countryByDecade": country_by_decade,
    "topInstitutions": top_institutions,
    "shareByDecade": share_by_decade_list,
    "migrationByDecade": migration_by_decade,
    "topFlows": top_flows,
    "femaleByDecade": female_by_decade,
    "funFacts": fun_facts,
    "records": records,
}

import os
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
print("records:", len(records))
print("kpis:", kpis)
print("size KB:", round(os.path.getsize(OUT) / 1024, 1))
print("sample age_by_category:", age_by_category[:3])
print("sample institutions:", top_institutions[:5])
print("sample flows:", top_flows[:4])
