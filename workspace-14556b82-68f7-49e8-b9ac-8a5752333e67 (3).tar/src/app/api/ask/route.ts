import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";
import { buildContext, type SourceRecord } from "@/lib/nobel-server";

export const runtime = "nodejs";
export const maxDuration = 120;

const SYSTEM_PROMPT = `You are "Ask Nobel" — a warm, knowledgeable guide answering questions about the Nobel Prize (1901-2026) for everyday people who are NOT data analysts.

Rules:
1. Answer ONLY from the CONTEXT given below. Never invent laureates, years, or numbers.
2. Use plain, friendly language. Short paragraphs (2-4 sentences) or a small bullet list when enumerating people. No jargon, no chart talk.
3. When the question mentions people, give their name, the prize year and category, and one interesting detail from their motivation.
4. If the context genuinely lacks the answer, say so honestly in one sentence, then share the closest interesting related fact you DO have from the context.
5. Keep answers under 180 words. Be engaging — this is a curiosity app, not a report.
6. Formatting: you may use **bold** for names/numbers and "- " bullets. No headings, no tables, no code blocks.

Mandatory last line — citations:
CITED: <comma-separated record ids from [Rid] entries you actually used>
Example: CITED: 451, 892
If you used no specific records, write: CITED: none`;

interface HistoryTurn {
  role: "user" | "assistant";
  content: string;
}

function parseCited(answer: string): number[] {
  const m = answer.match(/CITED:\s*([0-9,\s]+)?/i);
  if (!m) return [];
  const ids = (m[1] ?? "")
    .split(",")
    .map((s) => parseInt(s.trim(), 10))
    .filter((n) => !isNaN(n));
  return ids;
}

function stripCitedLine(answer: string): string {
  return answer.replace(/\n?CITED:.*$/im, "").trim();
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const question: string = (body.question ?? "").toString().trim();
    let conversationId: string | null = (body.conversationId ?? null) || null;
    const history: HistoryTurn[] = Array.isArray(body.history) ? body.history.slice(-8) : [];

    if (!question) {
      return NextResponse.json({ error: "Question is required" }, { status: 400 });
    }

    // 1. Conversation bookkeeping
    let title: string | undefined;
    if (!conversationId) {
      const conv = await db.conversation.create({
        data: {
          title: question.length > 60 ? question.slice(0, 57) + "..." : question,
        },
      });
      conversationId = conv.id;
      title = conv.title;
    }
    await db.message.create({
      data: { conversationId, role: "user", content: question },
    });

    // 2. Retrieve context from the Nobel dataset
    const ctx = buildContext(question);
    const contextBlock =
      "CONTEXT (trusted data):\n" + ctx.factLines.join("\n") + "\nEND CONTEXT.";

    // 3. Call the LLM
    const zai = await ZAI.create();
    const messages: { role: "user" | "assistant"; content: string }[] = [
      { role: "user", content: `${SYSTEM_PROMPT}\n\n${contextBlock}` },
    ];
    for (const turn of history) {
      messages.push({ role: turn.role, content: turn.content });
    }
    messages.push({ role: "user", content: question });

    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
    });

    let answer = completion.choices[0]?.message?.content ?? "";
    if (!answer.trim()) {
      answer =
        "I couldn't find that in the Nobel dataset — try asking about laureates, categories, countries, years, ages or prize facts.";
    }

    // 4. Citations -> source cards
    const citedIds = parseCited(answer);
    const cleaned = stripCitedLine(answer);
    let sources: SourceRecord[];
    if (citedIds.length > 0) {
      const idSet = new Set(citedIds);
      const cited = ctx.sourceCandidates.filter((s) => idSet.has(s.id));
      const rest = ctx.sourceCandidates.filter((s) => !idSet.has(s.id));
      sources = [...cited, ...rest].slice(0, 6);
    } else {
      sources = ctx.sourceCandidates.slice(0, 4);
    }

    // 5. Persist assistant message
    const saved = await db.message.create({
      data: {
        conversationId: conversationId!,
        role: "assistant",
        content: cleaned,
        sourcesJson: JSON.stringify(sources),
      },
    });
    await db.conversation.update({
      where: { id: conversationId },
      data: { updatedAt: new Date() },
    });

    return NextResponse.json({
      conversationId,
      title,
      messageId: saved.id,
      answer: cleaned,
      sources,
    });
  } catch (err) {
    console.error("[/api/ask] error:", err);
    return NextResponse.json(
      { error: "Something went wrong while answering. Please try again." },
      { status: 500 }
    );
  }
}
