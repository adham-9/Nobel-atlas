import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

export async function GET() {
  try {
    const conversations = await db.conversation.findMany({
      orderBy: { updatedAt: "desc" },
      take: 50,
      select: { id: true, title: true, updatedAt: true },
    });
    return NextResponse.json({ conversations });
  } catch (err) {
    console.error("[/api/conversations] error:", err);
    return NextResponse.json({ error: "Failed to load history" }, { status: 500 });
  }
}
