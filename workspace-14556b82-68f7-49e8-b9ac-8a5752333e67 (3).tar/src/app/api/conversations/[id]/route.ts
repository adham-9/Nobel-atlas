import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { SourceRecord } from "@/lib/nobel-server";

export const runtime = "nodejs";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const conversation = await db.conversation.findUnique({
      where: { id },
      include: {
        messages: { orderBy: { createdAt: "asc" } },
      },
    });
    if (!conversation) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    const messages = conversation.messages.map((m) => ({
      id: m.id,
      role: m.role as "user" | "assistant",
      content: m.content,
      sources: m.sourcesJson ? (JSON.parse(m.sourcesJson) as SourceRecord[]) : [],
    }));
    return NextResponse.json({
      conversation: {
        id: conversation.id,
        title: conversation.title,
      },
      messages,
    });
  } catch (err) {
    console.error("[/api/conversations/:id] error:", err);
    return NextResponse.json({ error: "Failed to load conversation" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.conversation.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[/api/conversations/:id] DELETE error:", err);
    return NextResponse.json({ error: "Failed to delete" }, { status: 500 });
  }
}
