import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Ask Nobel — Curious? Just ask.",
  description:
    "Ask anything about 125 years of Nobel Prize laureates and get plain-language answers. No charts, no jargon — just curiosity in, stories out.",
  keywords: ["Nobel Prize", "ask", "AI", "laureates", "questions", "answers"],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Ask Nobel — Curious? Just ask.",
    description:
      "The Nobel Prize, without the spreadsheets. Ask a question, get the story.",
    siteName: "Ask Nobel",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
