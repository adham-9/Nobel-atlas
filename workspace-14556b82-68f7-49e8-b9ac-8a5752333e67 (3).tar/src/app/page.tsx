"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, Sparkles, Plus } from "lucide-react";
import { AnimatedBackground } from "@/components/askly/animated-background";
import { Sidebar, type ConversationSummary } from "@/components/askly/sidebar";
import { Hero } from "@/components/askly/hero";
import { Thread, type ChatMessage } from "@/components/askly/thread";

export default function Page() {
  const [conversations, setConversations] = useState<ConversationSummary[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [question, setQuestion] = useState("");
  const [thinking, setThinking] = useState(false);
  const [loadingConv, setLoadingConv] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const lastQuestionRef = useRef<string>("");
  const stateRef = useRef({ activeId, messages });
  stateRef.current = { activeId, messages };

  const inChat = messages.length > 0 || loadingConv;

  /* ---------------- history list ---------------- */

  const refreshConversations = useCallback(async () => {
    try {
      const res = await fetch("/api/conversations");
      if (!res.ok) return;
      const data = await res.json();
      setConversations(data.conversations ?? []);
    } catch {
      /* non-fatal */
    }
  }, []);

  useEffect(() => {
    refreshConversations();
  }, [refreshConversations]);

  /* ---------------- core: ask ---------------- */

  const ask = useCallback(
    async (rawQuestion: string) => {
      const q = rawQuestion.trim();
      if (!q || thinking || loadingConv) return;

      lastQuestionRef.current = q;
      setError(null);
      setQuestion("");
      setSidebarOpen(false);

      const optimisticUser: ChatMessage = {
        id: `tmp-u-${Date.now()}`,
        role: "user",
        content: q,
      };
      const history = stateRef.current.messages
        .filter((m) => !m.id.startsWith("tmp-"))
        .map((m) => ({ role: m.role, content: m.content }))
        .slice(-8);

      setMessages((prev) => [...prev, optimisticUser]);
      setThinking(true);

      try {
        const res = await fetch("/api/ask", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            question: q,
            conversationId: stateRef.current.activeId,
            history,
          }),
        });
        if (!res.ok) throw new Error(`API ${res.status}`);
        const data = await res.json();

        setMessages((prev) => [
          ...prev,
          {
            id: data.messageId ?? `tmp-a-${Date.now()}`,
            role: "assistant",
            content: data.answer,
            sources: data.sources ?? [],
          },
        ]);
        setActiveId(data.conversationId);
        refreshConversations();
      } catch (err) {
        console.error("ask failed:", err);
        setError("Couldn't reach the archive. Check your connection and try again.");
      } finally {
        setThinking(false);
      }
    },
    [thinking, loadingConv, refreshConversations]
  );

  /* ---------------- conversations ---------------- */

  const startNew = useCallback(() => {
    setMessages([]);
    setActiveId(null);
    setQuestion("");
    setError(null);
    setSidebarOpen(false);
  }, []);

  const selectConversation = useCallback(async (id: string) => {
    setSidebarOpen(false);
    setError(null);
    setLoadingConv(true);
    try {
      const res = await fetch(`/api/conversations/${id}`);
      if (!res.ok) throw new Error("not found");
      const data = await res.json();
      setMessages(data.messages ?? []);
      setActiveId(id);
    } catch {
      setError("Couldn't open that conversation.");
    } finally {
      setLoadingConv(false);
    }
  }, []);

  const deleteConversation = useCallback(
    async (id: string) => {
      setConversations((prev) => prev.filter((c) => c.id !== id));
      if (stateRef.current.activeId === id) {
        setMessages([]);
        setActiveId(null);
      }
      try {
        await fetch(`/api/conversations/${id}`, { method: "DELETE" });
      } catch {
        /* already removed from UI */
      }
    },
    []
  );

  /* ---------------- render ---------------- */

  return (
    <div className="relative flex h-dvh overflow-hidden">
      <AnimatedBackground />
      <Sidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        conversations={conversations}
        activeId={activeId}
        onNew={startNew}
        onSelect={selectConversation}
        onDelete={deleteConversation}
      />

      <div className="flex min-w-0 flex-1 flex-col lg:pl-72">
        {/* Mobile top bar */}
        <header className="fixed inset-x-0 top-0 z-20 flex h-16 items-center gap-3 border-b border-white/5 bg-[oklch(0.145_0.005_75/0.8)] px-4 backdrop-blur-xl lg:hidden">
          <button
            onClick={() => setSidebarOpen(true)}
            aria-label="Open menu"
            className="rounded-xl p-2 text-foreground/80 transition-colors hover:bg-white/5"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-amber-400 via-orange-400 to-fuchsia-400">
              <Sparkles className="h-4 w-4 text-stone-900" strokeWidth={2.5} />
            </div>
            <span className="text-sm font-semibold">Ask Nobel</span>
          </div>
          {inChat && (
            <button
              onClick={startNew}
              aria-label="New question"
              className="ml-auto rounded-xl bg-gradient-to-r from-amber-400 to-orange-400 p-2 text-stone-900 shadow-md shadow-amber-500/20"
            >
              <Plus className="h-4 w-4" strokeWidth={3} />
            </button>
          )}
        </header>

        {/* Desktop compact header in chat mode */}
        <AnimatePresence>
          {inChat && (
            <motion.header
              initial={{ y: -60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -60, opacity: 0 }}
              transition={{ type: "spring", stiffness: 260, damping: 26 }}
              className="fixed inset-x-0 top-0 z-20 hidden h-16 items-center gap-3 border-b border-white/5 bg-[oklch(0.145_0.005_75/0.75)] px-6 backdrop-blur-xl lg:flex lg:pl-[19.5rem]"
            >
              <button
                onClick={startNew}
                className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400/90 to-orange-400/90 px-4 py-2 text-sm font-semibold text-stone-900 shadow-lg shadow-amber-500/10 transition-transform hover:scale-[1.03] active:scale-95"
              >
                <Plus className="h-4 w-4" strokeWidth={3} />
                New question
              </button>
              <p className="text-sm text-muted-foreground">
                {conversations.find((c) => c.id === activeId)?.title ??
                  "What do you wonder about?"}
              </p>
            </motion.header>
          )}
        </AnimatePresence>

        {/* Main switch: hero <-> thread */}
        <main className="flex min-h-0 flex-1 flex-col pt-16 lg:pt-0">
          <AnimatePresence mode="wait">
            {!inChat ? (
              <div key="hero-wrap" className="flex min-h-0 flex-1 flex-col">
                <Hero
                  question={question}
                  onChange={setQuestion}
                  onAsk={ask}
                  busy={thinking || loadingConv}
                />
              </div>
            ) : (
              <motion.div
                key="thread"
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 24 }}
                transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                className="flex min-h-0 flex-1 flex-col"
              >
                <Thread
                  messages={messages}
                  thinking={thinking}
                  question={question}
                  onQuestionChange={setQuestion}
                  onAsk={ask}
                  error={error}
                  onRetry={() => ask(lastQuestionRef.current)}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
