"use client";

import { useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowRightLeft,
  Award,
  Building2,
  CalendarClock,
  Globe2,
  Sparkles,
  Users,
  VenusAndMars,
} from "lucide-react";
import type { NobelData } from "@/lib/nobel";
import {
  AgeByCategoryChart,
  AgeTrendChart,
  CategoryDonut,
  FemaleTrendChart,
  GenderByCategoryChart,
  InstitutionsChart,
  MigrationChart,
  ShareDilutionChart,
  TimelineChart,
} from "./charts";
import { HeatGrid } from "./heatmap";
import { InsightsSection } from "./insights";
import { DataExplorer } from "./data-explorer";

function SectionCard({
  title,
  subtitle,
  icon,
  children,
  className = "",
  action,
}: {
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  action?: React.ReactNode;
}) {
  return (
    <section className={`rounded-xl border border-stone-800 bg-stone-900/60 p-5 ${className}`}>
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h3 className="flex items-center gap-2 font-serif text-base font-semibold text-stone-100">
            {icon}
            {title}
          </h3>
          {subtitle && <p className="mt-1 text-xs leading-relaxed text-stone-500">{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function KpiCard({
  icon,
  value,
  label,
  sub,
}: {
  icon: React.ReactNode;
  value: string;
  label: string;
  sub: string;
}) {
  return (
    <div className="rounded-xl border border-stone-800 bg-gradient-to-b from-stone-900 to-stone-950 p-4 transition-colors hover:border-amber-500/30">
      <div className="flex items-center gap-2 text-amber-500/90">
        {icon}
        <span className="text-[10px] font-semibold uppercase tracking-widest text-stone-500">{label}</span>
      </div>
      <div className="mt-2 font-serif text-3xl font-bold text-amber-300">{value}</div>
      <div className="mt-0.5 text-xs text-stone-500">{sub}</div>
    </div>
  );
}

export function Dashboard({ data }: { data: NobelData }) {
  const k = data.kpis;

  const repeat = useMemo(() => {
    const map = new Map<number, { name: string; n: number }>();
    for (const r of data.records) {
      const e = map.get(r.id);
      if (e) e.n += 1;
      else map.set(r.id, { name: r.name, n: 1 });
    }
    return Array.from(map.values())
      .filter((e) => e.n > 1)
      .sort((a, b) => b.n - a.n);
  }, [data.records]);

  return (
    <div className="min-h-screen bg-stone-950 text-stone-200">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-stone-800/80 bg-stone-950/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 shadow-[0_0_24px_rgba(245,158,11,0.35)] ring-2 ring-amber-500/40">
            <Award className="h-5 w-5 text-stone-950" />
          </div>
          <div className="min-w-0">
            <h1 className="truncate font-serif text-lg font-bold tracking-tight text-amber-200 sm:text-xl">
              Nobel Prize Analytics
            </h1>
            <p className="text-[11px] text-stone-500">
              125 years of human excellence · interactive dashboard of the laureate dataset
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-300">
              {k.yearMin}–{k.yearMax}
            </Badge>
            <Badge variant="outline" className="hidden border-stone-700 text-stone-400 sm:inline-flex">
              Official Nobel Foundation data
            </Badge>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {/* KPI row */}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
          <KpiCard
            icon={<Users className="h-4 w-4" />}
            value={k.totalLaureates.toLocaleString()}
            label="Laureates"
            sub={`${k.totalPrizeRecords.toLocaleString()} prize records`}
          />
          <KpiCard
            icon={<VenusAndMars className="h-4 w-4" />}
            value={`${k.femaleShare}%`}
            label="Female share"
            sub={`${k.femaleLaureates} women laureates`}
          />
          <KpiCard
            icon={<Building2 className="h-4 w-4" />}
            value={String(k.orgLaureates)}
            label="Organizations"
            sub="mostly Peace prizes"
          />
          <KpiCard
            icon={<Globe2 className="h-4 w-4" />}
            value={String(k.countries)}
            label="Countries"
            sub="of birth represented"
          />
          <KpiCard
            icon={<CalendarClock className="h-4 w-4" />}
            value={String(k.avgAge)}
            label="Avg age"
            sub={`range ${k.youngest}–${k.oldest} yrs`}
          />
          <KpiCard
            icon={<Sparkles className="h-4 w-4" />}
            value={String(k.repeatLaureates)}
            label="Repeat winners"
            sub="multiple Nobel prizes"
          />
        </div>

        <Tabs defaultValue="overview" className="mt-8">
          <TabsList className="border border-stone-800 bg-stone-900 text-stone-400">
            <TabsTrigger value="overview" className="data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-300">
              Overview
            </TabsTrigger>
            <TabsTrigger value="insights" className="data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-300">
              Insights ({12})
            </TabsTrigger>
            <TabsTrigger value="explorer" className="data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-300">
              Data Explorer
            </TabsTrigger>
          </TabsList>

          {/* ---------------- OVERVIEW ---------------- */}
          <TabsContent value="overview" className="mt-6 space-y-6">
            <SectionCard
              title="Awards Timeline, 1901 – 2026"
              subtitle="Laureates per year. Gray bands mark the World Wars; the dashed line marks the post-1976 acceleration found in the notebook."
            >
              <TimelineChart data={data.byYear} />
            </SectionCard>

            <div className="grid gap-6 lg:grid-cols-2">
              <SectionCard
                title="Prize Distribution by Category"
                subtitle="Share of all prize records across the six Nobel categories."
              >
                <CategoryDonut data={data.byCategory} />
              </SectionCard>
              <SectionCard
                title="Gender & Recipient Type by Category"
                subtitle="Individuals vs. organizations — institutions are almost exclusive to Peace."
              >
                <GenderByCategoryChart data={data.byCategory} />
              </SectionCard>
              <SectionCard
                title="Mean Age by Category"
                subtitle="Physics rewards early-career work; Economics and Literature reward lifetimes of scholarship. Hover for median & range."
              >
                <AgeByCategoryChart data={data.ageByCategory} />
              </SectionCard>
              <SectionCard
                title="Laureates Are Getting Older"
                subtitle="Mean and median age at award per decade — a clear upward drift across nearly all fields."
              >
                <AgeTrendChart data={data.ageByDecade} />
              </SectionCard>
            </div>

            <SectionCard
              title="Geographic Specialization — Country × Category"
              subtitle="Top 10 birth countries cross-tabulated with categories (row totals on the right). The United States dominates the empirical sciences."
              icon={<Globe2 className="h-4 w-4 text-amber-500" />}
            >
              <HeatGrid
                rows={data.countryByCategory.countries}
                cols={data.countryByCategory.categories ?? []}
                matrix={data.countryByCategory.matrix}
                rowTotals={data.countryByCategory.rowTotals}
                rowHeader="Birth country"
              />
            </SectionCard>

            <SectionCard
              title="A Century of Geopolitical Shifts — Country × Decade"
              subtitle="Top 8 countries by decade: European dominance pre-1940, the WWII dip, then the American surge from the 1950s. Scroll horizontally."
              icon={<Globe2 className="h-4 w-4 text-amber-500" />}
            >
              <HeatGrid
                rows={data.countryByDecade.countries}
                cols={data.countryByDecade.decades ?? []}
                matrix={data.countryByDecade.matrix}
                rowHeader="Birth country"
              />
            </SectionCard>

            <div className="grid gap-6 lg:grid-cols-2">
              <SectionCard
                title="Elite Research Hubs"
                subtitle="Most frequent award-time affiliations — the 'Matthew effect' of elite institutions."
                icon={<Building2 className="h-4 w-4 text-amber-500" />}
              >
                <InstitutionsChart data={data.topInstitutions} />
              </SectionCard>
              <SectionCard
                title="Prize Share Dilution"
                subtitle="Full (1/1), half (1/2) and third (1/3) shares per decade — modern science keeps maxing out the three-person cap."
              >
                <ShareDilutionChart data={data.shareByDecade} />
              </SectionCard>
              <SectionCard
                title="Brain Drain Persists"
                subtitle="Share of laureates conducting award-winning research outside their birth country — high and rising in modern decades."
                icon={<ArrowRightLeft className="h-4 w-4 text-amber-500" />}
                action={
                  data.funFacts.topFlow && (
                    <Badge variant="outline" className="border-rose-400/40 bg-rose-400/10 text-rose-300">
                      Top flow: {data.funFacts.topFlow.from} → {data.funFacts.topFlow.to} ({data.funFacts.topFlow.count})
                    </Badge>
                  )
                }
              >
                <MigrationChart data={data.migrationByDecade} />
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {data.topFlows.slice(0, 8).map((f) => (
                    <Badge
                      key={`${f.from}-${f.to}`}
                      variant="outline"
                      className="border-stone-800 bg-stone-950/60 text-[10px] font-normal text-stone-400"
                    >
                      {f.from} → {f.to} <span className="ml-1 font-semibold text-amber-400">{f.count}</span>
                    </Badge>
                  ))}
                </div>
              </SectionCard>
              <SectionCard
                title="Rise of Female Laureates"
                subtitle="Female laureates per decade with share of total — accelerating as women's access to science expands."
                icon={<VenusAndMars className="h-4 w-4 text-amber-500" />}
              >
                <FemaleTrendChart data={data.femaleByDecade} />
              </SectionCard>
            </div>

            {/* Fun facts */}
            <div className="grid gap-6 lg:grid-cols-3">
              <SectionCard title="Youngest Winners Ever" subtitle="Extreme early recognition">
                <ul className="space-y-2.5">
                  {data.funFacts.youngest.slice(0, 4).map((w) => (
                    <li key={w.name} className="flex items-baseline justify-between gap-2 text-sm">
                      <span className="truncate text-stone-200">{w.name}</span>
                      <span className="shrink-0 text-xs text-stone-500">
                        {w.category.split(" ")[0]} {w.year} · <span className="font-semibold text-amber-400">{w.age}</span>
                      </span>
                    </li>
                  ))}
                </ul>
              </SectionCard>
              <SectionCard title="Oldest Winners Ever" subtitle="Lifetime-work recognition">
                <ul className="space-y-2.5">
                  {data.funFacts.oldest.slice(0, 4).map((w) => (
                    <li key={w.name} className="flex items-baseline justify-between gap-2 text-sm">
                      <span className="truncate text-stone-200">{w.name}</span>
                      <span className="shrink-0 text-xs text-stone-500">
                        {w.category.split(" ")[0]} {w.year} · <span className="font-semibold text-amber-400">{w.age}</span>
                      </span>
                    </li>
                  ))}
                </ul>
              </SectionCard>
              <SectionCard title="Repeat Laureates" subtitle="Two-time (or more) Nobel winners in the dataset">
                <ul className="space-y-2.5">
                  {repeat.map((r) => (
                    <li key={r.name} className="flex items-baseline justify-between gap-2 text-sm">
                      <span className="truncate text-stone-200">{r.name}</span>
                      <span className="shrink-0 font-mono text-xs font-semibold text-amber-400">×{r.n}</span>
                    </li>
                  ))}
                </ul>
              </SectionCard>
            </div>
          </TabsContent>

          {/* ---------------- INSIGHTS ---------------- */}
          <TabsContent value="insights" className="mt-6">
            <InsightsSection />
          </TabsContent>

          {/* ---------------- EXPLORER ---------------- */}
          <TabsContent value="explorer" className="mt-6">
            <DataExplorer records={data.records} categories={k.categories} />
          </TabsContent>
        </Tabs>

        <footer className="mt-12 border-t border-stone-800/70 pt-6 text-center text-xs leading-relaxed text-stone-600">
          Built from the “After test” notebook analysis (data cleaning, 12 insights & final report) · Data refreshed
          from the official Nobel Foundation API (api.nobelprize.org) · Prize amounts in SEK
        </footer>
      </main>
    </div>
  );
}
