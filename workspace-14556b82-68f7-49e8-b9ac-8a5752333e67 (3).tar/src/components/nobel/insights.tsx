"use client";

import { Badge } from "@/components/ui/badge";
import {
  Atom,
  BookOpen,
  Building2,
  Clock,
  Globe2,
  Handshake,
  HeartHandshake,
  Layers,
  PieChart,
  TrendingUp,
  Users,
  VenusAndMars,
} from "lucide-react";

interface Insight {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  question: string;
  finding: string;
  interpretation: string;
  followUp: string;
}

const INSIGHTS: Insight[] = [
  {
    icon: Clock,
    title: "Age Distribution Across Categories",
    question: "How does laureate age vary across prize categories — which fields crown the youngest vs oldest winners?",
    finding:
      "Physics laureates tend to be the youngest on average (mean ≈ 56–58, minimum 25), while Economic Sciences (mean ≈ 66–68) and Literature (≈ 64–65) feature the oldest winners. The absolute youngest individual ever recorded won the Peace Prize at age 17.",
    interpretation:
      "The disparity mirrors how contributions are made: breakthroughs in Physics often stem from intense early-career research, whereas Literature and Economics typically recognize a lifetime of accumulated work and scholarly impact.",
    followUp: "Have average ages within these categories shifted higher over recent decades?",
  },
  {
    icon: VenusAndMars,
    title: "Female Representation & the Post-1970s Surge",
    question: "How has female representation evolved across decades, and what drives the post-1970s surge in award volume?",
    finding:
      "As women's education and support expanded, female laureates rose noticeably in recent decades versus earlier periods. From the early 1970s onward the data shows a massive surge in overall award volume.",
    interpretation:
      "This reflects modern scientific advancement and the profound impact of industrial and scientific revolutions that shaped today's research breakthroughs.",
    followUp: "Which categories show the fastest growth in female representation over the last 40 years?",
  },
  {
    icon: Globe2,
    title: "Geographic Specialization by Field",
    question: "Which nations dominate specific Nobel fields?",
    finding:
      "A select group of countries — led heavily by the United States — commands the majority of awards, with overwhelming dominance in Physics, Chemistry, and Physiology/Medicine.",
    interpretation:
      "Concentration reflects national research infrastructure, institutional funding, and historical science investment; other regions cluster around cultural and diplomatic fields such as Literature and Peace.",
    followUp: "Which non-US countries lead in Literature or Peace specializations?",
  },
  {
    icon: TrendingUp,
    title: "Geopolitical Shifts & the World Wars",
    question: "How do wartime disruptions and post-war shifts appear in laureate geography over time?",
    finding:
      "European powerhouses (Germany, UK) dominated 1900s–1930s, followed by a sharp 1940s dip during WWII. From the 1950s the United States surged, vastly outpacing all nations while emerging countries grew steadily.",
    interpretation:
      "The 1940s slump captures WWII brain drain and institutional collapse; post-war American dominance reflects massive research investment, elite university expansion (MIT, Stanford), and European scientists emigrating from conflict.",
    followUp: "Which European nations recovered Nobel productivity fastest after WWII?",
  },
  {
    icon: Building2,
    title: "Brain Drain: Birth vs. Affiliation",
    question: "Where do laureates conduct award-winning research compared to where they were born?",
    finding:
      "Several European and Asian countries produce many native-born laureates, but the United States shows far more institutional awards than native births — a notable share of laureates migrate to nations with advanced research ecosystems.",
    interpretation:
      "Nobel output concentrates where institutional attraction is strongest: excellence reflects a nation's ability to import, retain, and nurture global intellectual capital — not just domestic talent.",
    followUp: "Which home countries suffer the highest net brain drain relative to native-born laureates?",
  },
  {
    icon: Handshake,
    title: "Organizations vs. Individuals",
    question: "How are recipient types distributed across categories?",
    finding:
      "Institutional winners are almost exclusively concentrated in the Peace category — collective humanitarian and diplomatic achievements — while scientific fields are overwhelmingly individual.",
    interpretation:
      "Recognition is structurally tied to the recipient: institutional honors are bounded by diplomacy and peace-building, whereas individual awards track academic and creative participation trends.",
    followUp: "Which organizations have won multiple Peace Prizes, and how do they align with geopolitical milestones?",
  },
  {
    icon: PieChart,
    title: "Temporal Growth of Awards",
    question: "How has award volume evolved from 1901 to today?",
    finding:
      "A clear, compounding growth in awards and recognized laureates across decades — a sustained long-term upward trajectory from 1901 to the present.",
    interpretation:
      "The surge correlates with post-industrial expansion of higher education, rising R&D funding, and the modern rise of collaborative, multi-recipient discoveries.",
    followUp: "Which disciplines accelerated fastest in the post-WWII era?",
  },
  {
    icon: Layers,
    title: "Prize Share Dilution (1/1 → 1/3)",
    question: "How has the structural division of prizes evolved across decades?",
    finding:
      "Early decades were defined by solo awards or simple two-way splits; modern decades show overwhelming dominance of three-way (1/3) shares, with committees consistently maxing out the recipient limit.",
    interpretation:
      "A structural bottleneck: the Nobel Foundation's statute caps any prize at three people, forcing multi-person teams from massive collaborations into the rigid 1/3 quota — intensifying debates on who gets left out.",
    followUp: "Which field hits the three-person cap most frequently in modern decades?",
  },
  {
    icon: Building2,
    title: "Institutional Dominance & Elite Hubs",
    question: "Which universities accumulate the most Nobel laureates?",
    finding:
      "Awards concentrate in an elite tier: US institutions (Harvard, UC Berkeley, MIT, Columbia) alongside UK powerhouses (Cambridge, Oxford) capture a disproportionate share of scientific prizes.",
    interpretation:
      "The 'Matthew effect' in research — prestige, endowments, state-of-the-art labs, and talent attraction create self-reinforcing cycles of excellence that emerging institutions struggle to match.",
    followUp: "Which disciplines show the highest institutional monopoly by a single center?",
  },
  {
    icon: Users,
    title: "Single vs. Collaborative Prizes",
    question: "How has solo recognition shifted toward team awards over time?",
    finding:
      "Single-researcher prizes dominated the early 20th century; from mid-century onward — accelerating into modern decades — collaborative team awards became the primary mode of recognition.",
    interpretation:
      "Modern breakthroughs in physics, molecular biology, and chemistry demand multidisciplinary teams, large laboratories, and shared international resources — moving beyond the 'lone genius' era.",
    followUp: "Which disciplines transitioned to collaborative awards earliest?",
  },
  {
    icon: Atom,
    title: "The Aging Trend of Laureates",
    question: "Have laureates grown older over time?",
    finding:
      "A clear upward drift in average age from the early 20th century to today — modern laureates are consistently older across nearly all scientific and academic categories.",
    interpretation:
      "Compounding complexity of modern science: Nobel-worthy breakthroughs now require extended education pipelines, long postdoctoral phases, massive collaboration, and decades of empirical validation.",
    followUp: "Which category shows the steepest age increase over the last 50 years?",
  },
  {
    icon: Globe2,
    title: "Evolution of Global Scientific Mobility",
    question: "Has brain drain declined as global science develops, or does relocation remain necessary?",
    finding:
      "Rather than declining, migration toward elite hubs (particularly North America) has stayed remarkably high — and intensified in some modern decades — despite global improvements in education and infrastructure.",
    interpretation:
      "Nobel-level breakthroughs increasingly require hyper-specialized, multi-billion-dollar facilities and elite ecosystems, so brilliant minds still migrate to superpowers where these resources concentrate.",
    followUp: "Which world regions show the strongest persistent drain toward North America and Western Europe?",
  },
];

export function InsightsSection() {
  return (
    <div className="space-y-6">
      {/* Executive summary */}
      <div className="rounded-xl border border-amber-500/25 bg-gradient-to-br from-amber-500/10 via-stone-900 to-stone-900 p-6">
        <div className="mb-2 flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-amber-400" />
          <h3 className="font-serif text-lg font-semibold text-amber-200">Executive Summary</h3>
        </div>
        <p className="text-sm leading-relaxed text-stone-300">
          This dashboard operationalizes the full exploratory analysis from the original notebook — data cleaning,
          feature engineering, and twelve deep-dive insights on the Nobel Prize winners dataset
          (<span className="font-mono text-xs text-amber-300">nobel_prize_winners.csv</span>), refreshed with the
          latest official data. Asked what surprised us most:{" "}
          <span className="text-stone-100">
            despite the severe disruption of the world wars, the data reveals remarkable resilience — the world
            recovered and accelerated its scientific contributions rapidly, especially from around 1976.
          </span>
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Badge variant="outline" className="border-stone-700 text-stone-400">
            Cleaning · gender → “Organization” for institutional laureates
          </Badge>
          <Badge variant="outline" className="border-stone-700 text-stone-400">
            Pruned · categoryTopMotivation &amp; penName
          </Badge>
          <Badge variant="outline" className="border-stone-700 text-stone-400">
            Derived · Age, Decade, share tiers
          </Badge>
        </div>
      </div>

      {/* Insight cards */}
      <div className="grid gap-4 md:grid-cols-2">
        {INSIGHTS.map((ins, i) => (
          <article
            key={ins.title}
            className="group rounded-xl border border-stone-800 bg-stone-900/60 p-5 transition-colors hover:border-amber-500/40"
          >
            <div className="mb-3 flex items-start gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 ring-1 ring-amber-500/30">
                <ins.icon className="h-4.5 w-4.5 text-amber-400" />
              </div>
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-widest text-amber-500/80">
                  Insight {String(i + 1).padStart(2, "0")}
                </div>
                <h3 className="font-serif text-base font-semibold text-stone-100">{ins.title}</h3>
              </div>
            </div>
            <p className="mb-2 text-xs italic text-stone-400">“{ins.question}”</p>
            <p className="text-sm leading-relaxed text-stone-300">{ins.finding}</p>
            <p className="mt-2 text-sm leading-relaxed text-stone-400">{ins.interpretation}</p>
            <div className="mt-3 flex items-start gap-1.5 border-t border-stone-800 pt-3">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-500/80">Follow-up</span>
              <span className="text-xs text-stone-500">{ins.followUp}</span>
            </div>
          </article>
        ))}
      </div>

      <div className="flex items-center gap-2 pb-2 text-xs text-stone-500">
        <HeartHandshake className="h-3.5 w-3.5" />
        Findings and interpretations adapted verbatim from the original notebook report.
      </div>
    </div>
  );
}
