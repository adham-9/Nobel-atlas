"use client";

interface HeatGridProps {
  rows: string[];
  cols: string[];
  matrix: number[][];
  rowHeader: string;
  colHeader?: string;
  rowTotals?: number[];
}

/** Gold-scale categorical heatmap built with CSS grid (notebook's seaborn heatmap equivalent). */
export function HeatGrid({ rows, cols, matrix, rowHeader, colHeader, rowTotals }: HeatGridProps) {
  const max = Math.max(1, ...matrix.flat());
  const color = (v: number) => {
    if (v <= 0) return "rgba(255,255,255,0.025)";
    const t = Math.sqrt(v / max);
    return `rgba(251,191,36,${0.08 + t * 0.85})`;
  };
  const gridCols = `minmax(120px,auto) repeat(${cols.length}, minmax(40px,1fr))`;

  return (
    <div className="w-full overflow-x-auto">
      <div
        className="grid gap-px rounded-lg bg-stone-800/60 p-px"
        style={{ gridTemplateColumns: gridCols, minWidth: cols.length > 8 ? 860 : 560 }}
      >
        {/* header row */}
        <div className="bg-stone-900 px-2 py-1.5 text-[10px] font-medium uppercase tracking-wide text-stone-500">
          {rowHeader}
        </div>
        {cols.map((c) => (
          <div key={c} className="bg-stone-900 px-1 py-1.5 text-center text-[10px] font-medium uppercase tracking-wide text-stone-500">
            {c}
          </div>
        ))}
        {colHeader && (
          <div className="bg-stone-900 px-2 py-1 text-[9px] text-stone-600">{colHeader}</div>
        )}

        {/* data rows */}
        {rows.map((r, i) => (
          <div key={r} className="contents">
            <div className="flex items-center justify-between gap-2 bg-stone-900 px-2 py-1.5 text-xs text-stone-300">
              <span className="truncate" title={r}>{r}</span>
              {rowTotals && <span className="shrink-0 text-[10px] font-semibold text-amber-500/90">{rowTotals[i]}</span>}
            </div>
            {matrix[i].map((v, j) => {
              const bg = color(v);
              const bright = v > 0 && Math.sqrt(v / max) > 0.55;
              return (
                <div
                  key={j}
                  title={`${r} · ${cols[j]}: ${v}`}
                  className="flex items-center justify-center py-1.5 text-[11px] transition-transform hover:scale-[1.06] hover:ring-1 hover:ring-amber-300/60"
                  style={{ background: bg, color: bright ? "#1c1917" : v > 0 ? "#d6d3d1" : "#57534e" }}
                >
                  {v > 0 ? v : ""}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
