"use client";

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  ComposedChart,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceArea,
  ReferenceLine,
} from "recharts";
import {
  CATEGORY_COLORS,
  GENDER_COLORS,
  SHARE_COLORS,
  catShort,
  type NobelData,
  type YearPoint,
  type CategorySplit,
  type AgeByCategory,
  type AgeByDecade,
  type Institution,
  type ShareByDecade,
  type MigrationByDecade,
  type FemaleByDecade,
} from "@/lib/nobel";
import { ChartTip, AXIS_TICK, GRID_STROKE } from "./chart-bits";

const legendStyle = { fontSize: 11, color: "#a8a29e" };

export function TimelineChart({ data }: { data: YearPoint[] }) {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 16, bottom: 0, left: -18 }}>
          <defs>
            <linearGradient id="goldFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#fbbf24" stopOpacity={0.45} />
              <stop offset="100%" stopColor="#fbbf24" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke={GRID_STROKE} vertical={false} />
          <XAxis dataKey="year" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: "#44403c" }} interval={19} />
          <YAxis tick={AXIS_TICK} tickLine={false} axisLine={false} />
          <Tooltip content={<ChartTip />} cursor={{ stroke: "#fbbf24", strokeOpacity: 0.3 }} />
          <ReferenceArea x1={1914} x2={1918} fill="#78716c" fillOpacity={0.18} label={{ value: "WWI", fill: "#a8a29e", fontSize: 10, position: "insideTop" }} />
          <ReferenceArea x1={1939} x2={1945} fill="#78716c" fillOpacity={0.18} label={{ value: "WWII", fill: "#a8a29e", fontSize: 10, position: "insideTop" }} />
          <ReferenceLine x={1976} stroke="#fb7185" strokeDasharray="4 4" label={{ value: "1976 ↑", fill: "#fb7185", fontSize: 10, position: "insideTopRight" }} />
          <Area type="monotone" dataKey="laureates" name="Laureates" stroke="#fbbf24" strokeWidth={2} fill="url(#goldFill)" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CategoryDonut({ data }: { data: CategorySplit[] }) {
  return (
    <div className="flex h-[300px] w-full items-center">
      <ResponsiveContainer width="60%" height="100%">
        <PieChart>
          <Tooltip content={<ChartTip />} />
          <Pie
            data={data.map((d) => ({ ...d, name: d.short }))}
            dataKey="total"
            nameKey="name"
            innerRadius="62%"
            outerRadius="92%"
            paddingAngle={3}
            stroke="#0c0a09"
            strokeWidth={2}
          >
            {data.map((d) => (
              <Cell key={d.category} fill={CATEGORY_COLORS[d.category] ?? "#d6d3d1"} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div className="flex w-[40%] flex-col gap-1.5 pr-1">
        {data
          .slice()
          .sort((a, b) => b.total - a.total)
          .map((d) => (
            <div key={d.category} className="flex items-center gap-2 text-xs">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: CATEGORY_COLORS[d.category] }} />
              <span className="text-stone-300">{d.short}</span>
              <span className="ml-auto font-semibold text-amber-400">{d.total}</span>
            </div>
          ))}
      </div>
    </div>
  );
}

export function GenderByCategoryChart({ data }: { data: CategorySplit[] }) {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data.map((d) => ({ ...d, short: d.short }))} margin={{ top: 10, right: 8, bottom: 0, left: -22 }}>
          <CartesianGrid stroke={GRID_STROKE} vertical={false} />
          <XAxis dataKey="short" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: "#44403c" }} interval={0} angle={-18} dy={8} height={44} />
          <YAxis tick={AXIS_TICK} tickLine={false} axisLine={false} />
          <Tooltip content={<ChartTip />} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
          <Legend wrapperStyle={legendStyle} />
          <Bar dataKey="Male" stackId="g" fill={GENDER_COLORS.Male} radius={[0, 0, 0, 0]} />
          <Bar dataKey="Female" stackId="g" fill={GENDER_COLORS.Female} />
          <Bar dataKey="Organization" stackId="g" fill={GENDER_COLORS.Organization} radius={[3, 3, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function AgeByCategoryChart({ data }: { data: AgeByCategory[] }) {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 10, right: 8, bottom: 0, left: -22 }}>
          <CartesianGrid stroke={GRID_STROKE} vertical={false} />
          <XAxis dataKey="category" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: "#44403c" }} interval={0} angle={-18} dy={8} height={44} />
          <YAxis domain={[0, 100]} tick={AXIS_TICK} tickLine={false} axisLine={false} />
          <Tooltip
            content={<ChartTip formatter={(e) => {
              if (e.dataKey === "mean") {
                const p = e.payload as unknown as AgeByCategory;
                return `${p.mean} (median ${p.median}, ${p.min}–${p.max})`;
              }
              return String(e.value ?? "");
            }} />}
            cursor={{ fill: "rgba(255,255,255,0.04)" }}
          />
          <Bar dataKey="mean" name="Mean age" radius={[3, 3, 0, 0]} fill="#fbbf24" barSize={30} />
          <ReferenceLine y={60} stroke="#78716c" strokeDasharray="4 4" label={{ value: "60 yrs", fill: "#78716c", fontSize: 10, position: "insideTopRight" }} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}

export function AgeTrendChart({ data }: { data: AgeByDecade[] }) {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 10, right: 12, bottom: 0, left: -22 }}>
          <CartesianGrid stroke={GRID_STROKE} vertical={false} />
          <XAxis dataKey="decade" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: "#44403c" }} />
          <YAxis domain={[40, 75]} tick={AXIS_TICK} tickLine={false} axisLine={false} />
          <Tooltip content={<ChartTip />} cursor={{ stroke: "#fbbf24", strokeOpacity: 0.3 }} />
          <Legend wrapperStyle={legendStyle} />
          <Line type="monotone" dataKey="mean" name="Mean age" stroke="#fbbf24" strokeWidth={2.5} dot={{ r: 3, fill: "#fbbf24" }} />
          <Line type="monotone" dataKey="median" name="Median age" stroke="#2dd4bf" strokeWidth={1.5} strokeDasharray="5 3" dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function InstitutionsChart({ data }: { data: Institution[] }) {
  return (
    <div className="h-[440px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 4, right: 30, bottom: 0, left: 10 }}>
          <CartesianGrid stroke={GRID_STROKE} horizontal={false} />
          <XAxis type="number" tick={AXIS_TICK} tickLine={false} axisLine={false} />
          <YAxis
            type="category"
            dataKey="name"
            width={180}
            tick={{ fill: "#d6d3d1", fontSize: 10.5 }}
            tickLine={false}
            axisLine={{ stroke: "#44403c" }}
          />
          <Tooltip content={<ChartTip />} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
          <Bar dataKey="count" name="Laureates" fill="#f59e0b" radius={[0, 3, 3, 0]} barSize={14} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ShareDilutionChart({ data }: { data: ShareByDecade[] }) {
  return (
    <div className="h-[330px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 8, bottom: 0, left: -22 }}>
          <CartesianGrid stroke={GRID_STROKE} vertical={false} />
          <XAxis dataKey="decade" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: "#44403c" }} interval={1} />
          <YAxis tick={AXIS_TICK} tickLine={false} axisLine={false} />
          <Tooltip content={<ChartTip />} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
          <Legend wrapperStyle={legendStyle} />
          <Bar dataKey="full" name="Full prize 1/1" stackId="s" fill={SHARE_COLORS.full} />
          <Bar dataKey="half" name="Half share 1/2" stackId="s" fill={SHARE_COLORS.half} />
          <Bar dataKey="third" name="Third share 1/3" stackId="s" fill={SHARE_COLORS.third} />
          <Bar dataKey="quarter" name="Quarter share 1/4" stackId="s" fill={SHARE_COLORS.quarter} radius={[3, 3, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function MigrationChart({ data }: { data: MigrationByDecade[] }) {
  return (
    <div className="h-[250px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 10, bottom: 0, left: -22 }}>
          <defs>
            <linearGradient id="migFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#fb7185" stopOpacity={0.4} />
              <stop offset="100%" stopColor="#fb7185" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke={GRID_STROKE} vertical={false} />
          <XAxis dataKey="decade" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: "#44403c" }} />
          <YAxis domain={[0, 50]} unit="%" tick={AXIS_TICK} tickLine={false} axisLine={false} />
          <Tooltip
            content={<ChartTip formatter={(e) => `${e.value}%`} />}
            cursor={{ stroke: "#fb7185", strokeOpacity: 0.3 }}
          />
          <Area type="monotone" dataKey="migrantPct" name="Migrant laureates" stroke="#fb7185" strokeWidth={2} fill="url(#migFill)" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function FemaleTrendChart({ data }: { data: FemaleByDecade[] }) {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 10, right: 4, bottom: 0, left: -22 }}>
          <CartesianGrid stroke={GRID_STROKE} vertical={false} />
          <XAxis dataKey="decade" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: "#44403c" }} />
          <YAxis yAxisId="left" tick={AXIS_TICK} tickLine={false} axisLine={false} />
          <YAxis yAxisId="right" orientation="right" unit="%" tick={AXIS_TICK} tickLine={false} axisLine={false} />
          <Tooltip content={<ChartTip />} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
          <Legend wrapperStyle={legendStyle} />
          <Bar yAxisId="left" dataKey="female" name="Female laureates" fill="#fb7185" radius={[3, 3, 0, 0]} barSize={16} />
          <Line yAxisId="right" type="monotone" dataKey="femalePct" name="Share %" stroke="#fbbf24" strokeWidth={2} dot={{ r: 2.5 }} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
