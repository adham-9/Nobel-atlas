"use client";

import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ChevronLeft, ChevronRight, ExternalLink, Search, Trophy } from "lucide-react";
import { catColor, catShort, type NobelRecord } from "@/lib/nobel";

const PAGE_SIZE = 12;

const genderBadge = (g: string) => {
  if (g === "Female") return "border-rose-400/40 bg-rose-400/10 text-rose-300";
  if (g === "Male") return "border-amber-400/40 bg-amber-400/10 text-amber-300";
  return "border-stone-500/40 bg-stone-500/10 text-stone-300";
};

export function DataExplorer({ records, categories }: { records: NobelRecord[]; categories: string[] }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [gender, setGender] = useState("all");
  const [decade, setDecade] = useState("all");
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<NobelRecord | null>(null);

  const decades = useMemo(
    () => Array.from(new Set(records.map((r) => r.decade))).sort((a, b) => b - a),
    [records]
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return records.filter((r) => {
      if (category !== "all" && r.category !== category) return false;
      if (gender !== "all" && r.gender !== gender) return false;
      if (decade !== "all" && r.decade !== Number(decade)) return false;
      if (!q) return true;
      return (
        r.name.toLowerCase().includes(q) ||
        (r.birthCountry ?? "").toLowerCase().includes(q) ||
        (r.affiliation ?? "").toLowerCase().includes(q) ||
        (r.affiliationCountry ?? "").toLowerCase().includes(q) ||
        r.motivation.toLowerCase().includes(q)
      );
    });
  }, [records, query, category, gender, decade]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pageCount - 1);
  const rows = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);

  const go = (p: number) => setPage(Math.min(Math.max(0, p), pageCount - 1));

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-500" />
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(0);
            }}
            placeholder="Search name, country, institution, or motivation…"
            className="border-stone-800 bg-stone-900 pl-9 text-stone-200 placeholder:text-stone-600 focus-visible:ring-amber-500/40"
          />
        </div>
        <div className="grid grid-cols-3 gap-2 md:flex">
          <Select
            value={category}
            onValueChange={(v) => {
              setCategory(v);
              setPage(0);
            }}
          >
            <SelectTrigger className="w-full border-stone-800 bg-stone-900 text-stone-200 md:w-[150px]">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent className="border-stone-800 bg-stone-900 text-stone-200">
              <SelectItem value="all">All categories</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>
                  {catShort(c)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select
            value={gender}
            onValueChange={(v) => {
              setGender(v);
              setPage(0);
            }}
          >
            <SelectTrigger className="w-full border-stone-800 bg-stone-900 text-stone-200 md:w-[130px]">
              <SelectValue placeholder="Gender" />
            </SelectTrigger>
            <SelectContent className="border-stone-800 bg-stone-900 text-stone-200">
              <SelectItem value="all">All types</SelectItem>
              <SelectItem value="Male">Male</SelectItem>
              <SelectItem value="Female">Female</SelectItem>
              <SelectItem value="Organization">Organization</SelectItem>
            </SelectContent>
          </Select>
          <Select
            value={decade}
            onValueChange={(v) => {
              setDecade(v);
              setPage(0);
            }}
          >
            <SelectTrigger className="w-full border-stone-800 bg-stone-900 text-stone-200 md:w-[120px]">
              <SelectValue placeholder="Decade" />
            </SelectTrigger>
            <SelectContent className="border-stone-800 bg-stone-900 text-stone-200">
              <SelectItem value="all">All decades</SelectItem>
              {decades.map((d) => (
                <SelectItem key={d} value={String(d)}>
                  {d}s
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="text-xs text-stone-500">
        {filtered.length.toLocaleString()} records
        {filtered.length !== records.length && ` (of ${records.length.toLocaleString()})`}
      </div>

      {/* Table */}
      <div className="max-h-[640px] overflow-y-auto rounded-lg border border-stone-800">
        <Table>
          <TableHeader className="sticky top-0 z-10 bg-stone-900/95 backdrop-blur">
            <TableRow className="border-stone-800 hover:bg-transparent">
              <TableHead className="w-[70px] text-stone-400">Year</TableHead>
              <TableHead className="text-stone-400">Laureate</TableHead>
              <TableHead className="w-[120px] text-stone-400">Category</TableHead>
              <TableHead className="w-[70px] text-stone-400">Share</TableHead>
              <TableHead className="w-[64px] text-stone-400">Age</TableHead>
              <TableHead className="hidden w-[140px] text-stone-400 md:table-cell">Birth country</TableHead>
              <TableHead className="hidden w-[200px] text-stone-400 lg:table-cell">Affiliation</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow
                key={`${r.id}-${r.year}-${r.category}`}
                className="cursor-pointer border-stone-800/70 hover:bg-stone-900/70"
                onClick={() => setSelected(r)}
              >
                <TableCell className="font-mono text-xs text-amber-400">{r.year}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-stone-200">{r.name}</span>
                    <Badge variant="outline" className={`px-1.5 text-[10px] ${genderBadge(r.gender)}`}>
                      {r.gender === "Organization" ? "ORG" : r.gender === "Female" ? "F" : "M"}
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="inline-flex items-center gap-1.5 text-xs text-stone-300">
                    <span className="h-2 w-2 rounded-full" style={{ background: catColor(r.category) }} />
                    {catShort(r.category)}
                  </span>
                </TableCell>
                <TableCell className="font-mono text-xs text-stone-400">{r.portion}</TableCell>
                <TableCell className="font-mono text-xs text-stone-400">{r.age ?? "—"}</TableCell>
                <TableCell className="hidden text-xs text-stone-400 md:table-cell">
                  {r.birthCountry ?? "—"}
                </TableCell>
                <TableCell className="hidden max-w-[200px] truncate text-xs text-stone-400 lg:table-cell" title={r.affiliation ?? ""}>
                  {r.affiliation ?? "—"}
                </TableCell>
              </TableRow>
            ))}
            {rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="py-10 text-center text-sm text-stone-500">
                  No laureates match your filters.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-stone-500">
          Page {safePage + 1} of {pageCount}
        </span>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => go(safePage - 1)}
            disabled={safePage === 0}
            className="border-stone-800 bg-stone-900 text-stone-300 hover:bg-stone-800 hover:text-amber-300"
          >
            <ChevronLeft className="h-4 w-4" /> Prev
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => go(safePage + 1)}
            disabled={safePage >= pageCount - 1}
            className="border-stone-800 bg-stone-900 text-stone-300 hover:bg-stone-800 hover:text-amber-300"
          >
            Next <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Detail dialog */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="border-stone-700 bg-stone-900 text-stone-200 sm:max-w-lg">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex flex-wrap items-center gap-2 font-serif text-xl text-amber-200">
                  <Trophy className="h-5 w-5 text-amber-400" />
                  {selected.name}
                </DialogTitle>
                <DialogDescription className="text-sm text-stone-400">
                  {selected.categoryFullName ?? selected.category} · {selected.year}
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <Fact label="Category" value={selected.category} />
                <Fact label="Prize share" value={selected.portion} />
                <Fact label="Age at award" value={selected.age != null ? `${selected.age} years` : "—"} />
                <Fact label="Gender / type" value={selected.gender} />
                <Fact
                  label="Born"
                  value={
                    selected.birthYear
                      ? `${selected.birthYear}${selected.birthCity ? ` · ${selected.birthCity}` : ""}`
                      : "—"
                  }
                />
                <Fact label="Birth country" value={selected.birthCountry ?? "—"} />
                <Fact label="Affiliation" value={selected.affiliation ?? "—"} />
                <Fact
                  label="Affiliation country"
                  value={selected.affiliationCountry ?? "—"}
                />
                <Fact
                  label="Prize amount (SEK)"
                  value={selected.prizeAmount ? selected.prizeAmount.toLocaleString() : "—"}
                />
                <Fact
                  label="Adjusted (SEK)"
                  value={selected.prizeAmountAdjusted ? selected.prizeAmountAdjusted.toLocaleString() : "—"}
                />
                <Fact label="Award announced" value={selected.dateAwarded ?? "—"} />
                <Fact label="Died" value={selected.deathYear ? String(selected.deathYear) : selected.indOrOrg === "Individual" ? "—" : "n/a"} />
              </div>
              <div className="rounded-lg border border-stone-800 bg-stone-950/60 p-3">
                <div className="mb-1 text-[10px] font-semibold uppercase tracking-widest text-amber-500/80">
                  Motivation
                </div>
                <p className="text-sm leading-relaxed text-stone-300">
                  {selected.motivation || "—"}
                </p>
              </div>
              <a
                href={selected.laureateUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300"
              >
                <ExternalLink className="h-3.5 w-3.5" /> Official laureate page
              </a>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-stone-800 bg-stone-950/50 px-3 py-2">
      <div className="text-[10px] uppercase tracking-wider text-stone-500">{label}</div>
      <div className="mt-0.5 truncate text-stone-200" title={value}>
        {value}
      </div>
    </div>
  );
}
