"use client";

import { catColor } from "@/lib/nobel";

interface TooltipEntry {
  name?: string | number;
  value?: string | number;
  color?: string;
  dataKey?: string | number;
  payload?: Record<string, unknown>;
}

export function ChartTip({
  active,
  payload,
  label,
  formatter,
}: {
  active?: boolean;
  payload?: TooltipEntry[];
  label?: string | number;
  formatter?: (entry: TooltipEntry) => string;
}) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="rounded-lg border border-stone-700 bg-stone-900/95 px-3 py-2 shadow-xl backdrop-blur-sm">
      {label !== undefined && label !== "" && (
        <div className="mb-1 text-xs font-semibold text-amber-400">{label}</div>
      )}
      <div className="space-y-0.5">
        {payload.map((e, i) => (
          <div key={i} className="flex items-center gap-2 text-xs text-stone-200">
            <span
              className="inline-block h-2 w-2 rounded-full"
              style={{ background: e.color ?? catColor(String(e.name ?? "")) }}
            />
            <span className="text-stone-400">{e.name}</span>
            <span className="ml-auto pl-3 font-semibold text-stone-100">
              {formatter ? formatter(e) : e.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export const AXIS_TICK = { fill: "#a8a29e", fontSize: 11 };
export const GRID_STROKE = "rgba(255,255,255,0.07)";
