"use client";

import { motion } from "framer-motion";
import { Composer } from "./composer";

const SUGGESTIONS = [
  "Who was the youngest laureate ever?",
  "How many women have won the Nobel Prize?",
  "Which country has the most winners?",
  "Who won the prize twice?",
  "What happened in 1940?",
  "Who was the first woman to win?",
];

const STATS = [
  { value: "1,028", label: "laureates", question: "Tell me an overview of all Nobel laureates" },
  { value: "69", label: "women", question: "How many women have won the Nobel Prize and who are some of them?" },
  { value: "86", label: "countries", question: "Which countries produce the most Nobel laureates?" },
  { value: "125", label: "years", question: "How has the Nobel Prize changed over the decades?" },
];

const headline = "What do you wonder about?";

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06, delayChildren: 0.1 } },
};

const item = {
  hidden: { opacity: 0, y: 24, filter: "blur(6px)" },
  show: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { type: "spring" as const, stiffness: 120, damping: 18 },
  },
};

interface HeroProps {
  question: string;
  onChange: (v: string) => void;
  onAsk: (q: string) => void;
  busy: boolean;
}

export function Hero({ question, onChange, onAsk, busy }: HeroProps) {
  return (
    <motion.div
      key="hero"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, y: -40, filter: "blur(8px)", transition: { duration: 0.35 } }}
      className="flex min-h-full flex-col items-center justify-center px-4 py-10"
    >
      <motion.div variants={container} initial="hidden" animate="show" className="w-full max-w-3xl">
        {/* Eyebrow badge */}
        <motion.div variants={item} className="mb-6 flex justify-center">
          <div className="glass flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-amber-200/90">
            <span className="animate-pulse-glow h-1.5 w-1.5 rounded-full bg-amber-300" />
            125 years of Nobel history · zero spreadsheets
          </div>
        </motion.div>

        {/* Headline */}
        <motion.h1
          variants={item}
          className="text-center text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl"
        >
          <span className="text-gradient-warm">{headline}</span>
        </motion.h1>

        <motion.p
          variants={item}
          className="mx-auto mt-4 max-w-xl text-center text-base leading-relaxed text-muted-foreground sm:text-lg"
        >
          Ask in your own words — no charts, no data skills needed.
          Ask Nobel digs through every laureate since 1901 and tells you the story.
        </motion.p>

        {/* Composer */}
        <motion.div variants={item} className="mt-8">
          <Composer
            value={question}
            onChange={onChange}
            onSubmit={() => onAsk(question)}
            busy={busy}
            variant="hero"
          />
        </motion.div>

        {/* Suggestion chips */}
        <motion.div variants={item} className="mt-5 flex flex-wrap justify-center gap-2">
          {SUGGESTIONS.map((s, i) => (
            <motion.button
              key={s}
              onClick={() => onAsk(s)}
              disabled={busy}
              whileHover={{ scale: 1.04, y: -2 }}
              whileTap={{ scale: 0.96 }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.55 + i * 0.07 }}
              className="glass rounded-full px-4 py-2 text-[13px] text-foreground/80 transition-colors hover:border-amber-400/40 hover:text-amber-200 disabled:opacity-50"
            >
              {s}
            </motion.button>
          ))}
        </motion.div>

        {/* Stat tiles */}
        <motion.div variants={item} className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {STATS.map((st, i) => (
            <motion.button
              key={st.label}
              onClick={() => onAsk(st.question)}
              disabled={busy}
              whileHover={{ y: -4, scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 + i * 0.08, type: "spring", stiffness: 140, damping: 16 }}
              className="glass group rounded-2xl px-4 py-4 text-center transition-colors hover:border-amber-400/30 disabled:opacity-50"
            >
              <p className="bg-gradient-to-br from-amber-300 to-orange-400 bg-clip-text text-2xl font-bold text-transparent sm:text-3xl">
                {st.value}
              </p>
              <p className="mt-0.5 text-xs text-muted-foreground group-hover:text-amber-200/80">
                {st.label}
              </p>
            </motion.button>
          ))}
        </motion.div>
      </motion.div>
    </motion.div>
  );
}
