"use client";

import { useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowUp, Loader2 } from "lucide-react";

interface ComposerProps {
  value: string;
  onChange: (v: string) => void;
  onSubmit: () => void;
  busy?: boolean;
  variant?: "hero" | "docked";
  placeholder?: string;
}

export function Composer({
  value,
  onChange,
  onSubmit,
  busy = false,
  variant = "docked",
  placeholder = "Ask anything about the Nobel Prize…",
}: ComposerProps) {
  const ref = useRef<HTMLTextAreaElement>(null);

  // Auto-resize
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 160) + "px";
  }, [value]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (!busy && value.trim()) onSubmit();
    }
  };

  const hero = variant === "hero";

  return (
    <motion.div
      className={
        hero
          ? "glass rounded-3xl p-2 shadow-2xl shadow-black/30 focus-within:border-amber-400/40 transition-colors duration-300"
          : "glass rounded-3xl p-2 shadow-lg shadow-black/20 focus-within:border-amber-400/40 transition-colors duration-300"
      }
      whileFocus={{ scale: 1.01 }}
    >
      <div className="flex items-end gap-2">
        <textarea
          ref={ref}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          rows={1}
          aria-label="Ask a question about the Nobel Prize"
          placeholder={placeholder}
          className={`scrollbar-thin flex-1 resize-none bg-transparent px-4 py-3 text-foreground placeholder:text-muted-foreground/70 focus:outline-none ${
            hero ? "text-lg sm:text-xl" : "text-base"
          }`}
        />
        <motion.button
          onClick={onSubmit}
          disabled={busy || !value.trim()}
          aria-label="Send question"
          whileHover={busy || !value.trim() ? undefined : { scale: 1.08 }}
          whileTap={busy || !value.trim() ? undefined : { scale: 0.92 }}
          className={`mb-1 mr-1 grid h-11 w-11 shrink-0 place-items-center rounded-2xl transition-all duration-300 ${
            busy || !value.trim()
              ? "bg-white/5 text-muted-foreground cursor-not-allowed"
              : "bg-gradient-to-br from-amber-400 to-orange-500 text-stone-900 shadow-lg shadow-amber-500/25"
          }`}
        >
          {busy ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <ArrowUp className="h-5 w-5" strokeWidth={2.5} />
          )}
        </motion.button>
      </div>
    </motion.div>
  );
}
