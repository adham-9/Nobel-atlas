"use client";

import { motion } from "framer-motion";

/**
 * Full-screen animated backdrop: floating warm gradient orbs,
 * a faint grid and a soft vignette. Purely decorative.
 */
export function AnimatedBackground() {
  return (
    <div
      aria-hidden
      className="fixed inset-0 -z-10 overflow-hidden bg-[oklch(0.145_0.005_75)]"
    >
      {/* Faint grid */}
      <div
        className="absolute inset-0 opacity-[0.05]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.5) 1px, transparent 1px)",
          backgroundSize: "72px 72px",
          maskImage:
            "radial-gradient(ellipse 90% 70% at 50% 30%, black 30%, transparent 75%)",
          WebkitMaskImage:
            "radial-gradient(ellipse 90% 70% at 50% 30%, black 30%, transparent 75%)",
        }}
      />

      {/* Orbs */}
      <div
        className="animate-float-slow absolute -top-32 -left-24 h-[34rem] w-[34rem] rounded-full opacity-30 blur-3xl"
        style={{
          background:
            "radial-gradient(circle at 35% 35%, rgba(251,191,36,0.55), transparent 65%)",
        }}
      />
      <div
        className="animate-float-slower absolute top-1/4 -right-40 h-[38rem] w-[38rem] rounded-full opacity-25 blur-3xl"
        style={{
          background:
            "radial-gradient(circle at 60% 40%, rgba(240,171,252,0.5), transparent 65%)",
        }}
      />
      <div
        className="animate-float-slow absolute -bottom-48 left-1/3 h-[36rem] w-[36rem] rounded-full opacity-20 blur-3xl"
        style={{
          background:
            "radial-gradient(circle at 50% 50%, rgba(45,212,191,0.45), transparent 65%)",
          animationDelay: "-9s",
        }}
      />
      <div
        className="animate-float-slower absolute top-[60%] left-[8%] h-[22rem] w-[22rem] rounded-full opacity-20 blur-3xl"
        style={{
          background:
            "radial-gradient(circle at 50% 50%, rgba(251,113,133,0.4), transparent 65%)",
          animationDelay: "-14s",
        }}
      />

      {/* Vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,rgba(0,0,0,0.5)_100%)]" />
    </div>
  );
}

/** The glowing laureate-medallion logo mark. */
export function AskNobelMark({ size = 40 }: { size?: number }) {
  return (
    <motion.div
      className="relative grid place-items-center rounded-2xl"
      style={{ width: size, height: size }}
      whileHover={{ rotate: 8, scale: 1.08 }}
      transition={{ type: "spring", stiffness: 300, damping: 15 }}
    >
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-amber-400 via-orange-400 to-fuchsia-400 opacity-90" />
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-amber-400 via-orange-400 to-fuchsia-400 blur-md opacity-40" />
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="rgba(30,20,5,0.9)"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="relative"
        style={{ width: size * 0.55, height: size * 0.55 }}
      >
        <circle cx="12" cy="8" r="5" />
        <path d="M8.5 12.5 7 22l5-3 5 3-1.5-9.5" />
      </svg>
    </motion.div>
  );
}
