"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Plus, MessageCircle, Trash2, X, Sparkles } from "lucide-react";

export interface ConversationSummary {
  id: string;
  title: string;
  updatedAt: string;
}

interface SidebarProps {
  open: boolean;
  onClose: () => void;
  conversations: ConversationSummary[];
  activeId: string | null;
  onNew: () => void;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
}

function SidebarContent({
  conversations,
  activeId,
  onNew,
  onSelect,
  onDelete,
}: Omit<SidebarProps, "open" | "onClose">) {
  return (
    <div className="flex h-full flex-col">
      {/* Brand */}
      <div className="flex items-center gap-3 px-4 pt-5 pb-4">
        <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-amber-400 via-orange-400 to-fuchsia-400">
          <Sparkles className="h-4.5 w-4.5 text-stone-900" strokeWidth={2.5} />
        </div>
        <div>
          <p className="text-sm font-semibold tracking-tight">Ask Nobel</p>
          <p className="text-[11px] text-muted-foreground">125 years of curiosity</p>
        </div>
      </div>

      {/* New question */}
      <div className="px-3 pb-3">
        <motion.button
          onClick={onNew}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          className="flex w-full items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400/90 to-orange-400/90 px-4 py-2.5 text-sm font-semibold text-stone-900 shadow-lg shadow-amber-500/10"
        >
          <Plus className="h-4 w-4" strokeWidth={3} />
          New question
        </motion.button>
      </div>

      {/* History */}
      <p className="px-5 pb-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
        History
      </p>
      <div className="scrollbar-thin flex-1 overflow-y-auto px-3 pb-4">
        <AnimatePresence initial={false}>
          {conversations.length === 0 && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="px-2 py-6 text-center text-xs leading-relaxed text-muted-foreground"
            >
              Your questions will appear here.
              <br />
              Ask your first one →
            </motion.p>
          )}
          {conversations.map((c) => (
            <motion.div
              key={c.id}
              layout
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12, height: 0 }}
              transition={{ type: "spring", stiffness: 320, damping: 28 }}
              className="group relative mb-1"
            >
              <button
                onClick={() => onSelect(c.id)}
                className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 pr-9 text-left text-[13px] transition-colors ${
                  activeId === c.id
                    ? "bg-amber-400/10 text-amber-200"
                    : "text-foreground/75 hover:bg-white/5 hover:text-foreground"
                }`}
              >
                <MessageCircle
                  className={`h-3.5 w-3.5 shrink-0 ${
                    activeId === c.id ? "text-amber-300" : "text-muted-foreground"
                  }`}
                />
                <span className="line-clamp-2 leading-snug">{c.title}</span>
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(c.id);
                }}
                aria-label={`Delete conversation: ${c.title}`}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-muted-foreground opacity-0 transition-all hover:bg-red-500/15 hover:text-red-400 focus:opacity-100 group-hover:opacity-100"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <div className="border-t border-white/5 px-5 py-4">
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          Nobel Foundation dataset · 1901–2026 · 1,028 laureates
        </p>
      </div>
    </div>
  );
}

export function Sidebar(props: SidebarProps) {
  const { open, onClose, ...rest } = props;
  return (
    <>
      {/* Desktop */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-72 border-r border-white/5 bg-[oklch(0.165_0.007_75/0.7)] backdrop-blur-xl lg:block">
        <SidebarContent {...rest} />
      </aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
              className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
            />
            <motion.aside
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 32 }}
              className="fixed inset-y-0 left-0 z-50 w-72 border-r border-white/10 bg-[oklch(0.165_0.007_75)] lg:hidden"
            >
              <button
                onClick={onClose}
                aria-label="Close menu"
                className="absolute right-3 top-4 rounded-lg p-2 text-muted-foreground hover:bg-white/5 hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
              <SidebarContent {...rest} />
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
