"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { RefreshCw } from "lucide-react";
import { Composer } from "./composer";
import type { SourceRecord } from "@/lib/nobel-server";
import { catColor, catShort } from "@/lib/nobel";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources?: SourceRecord[];
}

/* ------------------------------------------------------------------ */
/* Source cards                                                        */
/* ------------------------------------------------------------------ */

function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join("");
}

function SourceCard({ source, index }: { source: SourceRecord; index: number }) {
  const color = catColor(source.category);
  return (
    <motion.div
      initial={{ opacity: 0, y: 14, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay: 0.15 + index * 0.08, type: "spring", stiffness: 200, damping: 22 }}
      whileHover={{ y: -3 }}
      className="glass w-52 shrink-0 rounded-2xl p-3"
      style={{ borderColor: `${color}33` }}
    >
      <div className="flex items-center gap-2.5">
        <div
          className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[11px] font-bold text-stone-900"
          style={{ background: color }}
        >
          {initials(source.name)}
        </div>
        <div className="min-w-0">
          <p className="truncate text-[13px] font-semibold leading-tight" title={source.name}>
            {source.name}
          </p>
          <p className="mt-0.5 flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <span
              className="inline-block h-1.5 w-1.5 rounded-full"
              style={{ background: color }}
            />
            {catShort(source.category)} · {source.year}
          </p>
        </div>
      </div>
      <p className="mt-2 line-clamp-2 text-[11px] leading-relaxed text-muted-foreground">
        {source.motivation}
      </p>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/* Thinking indicator                                                  */
/* ------------------------------------------------------------------ */

const THINKING_STEPS = [
  "Searching 125 years of laureates…",
  "Reading prize motivations…",
  "Cross-checking countries and categories…",
  "Polishing the story…",
];

function ThinkingBubble() {
  const [step, setStep] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setStep((s) => Math.min(s + 1, THINKING_STEPS.length - 1)), 1400);
    return () => clearInterval(t);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8, transition: { duration: 0.2 } }}
      className="flex items-center gap-3"
    >
      <div className="relative grid h-9 w-9 place-items-center">
        <div className="absolute inset-0 animate-ping rounded-full bg-amber-400/20" />
        <div className="h-3.5 w-3.5 animate-pulse rounded-full bg-gradient-to-br from-amber-300 to-orange-500" />
      </div>
      <div className="flex items-center gap-2.5">
        <div className="flex gap-1">
          {[0, 1, 2].map((i) => (
            <motion.span
              key={i}
              className="h-2 w-2 rounded-full bg-amber-300/80"
              animate={{ y: [0, -5, 0], opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.15 }}
            />
          ))}
        </div>
        <AnimatePresence mode="wait">
          <motion.span
            key={step}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            className="text-xs text-muted-foreground"
          >
            {THINKING_STEPS[step]}
          </motion.span>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/* Message bubble                                                      */
/* ------------------------------------------------------------------ */

function MessageBubble({ message }: { message: ChatMessage }) {
  if (message.role === "user") {
    return (
      <motion.div
        layout
        initial={{ opacity: 0, y: 16, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 24 }}
        className="flex justify-end"
      >
        <div className="max-w-[85%] rounded-3xl rounded-br-lg bg-gradient-to-br from-amber-400/90 to-orange-500/90 px-5 py-3 text-[15px] font-medium text-stone-900 shadow-lg shadow-amber-500/10 sm:max-w-[70%]">
          {message.content}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 200, damping: 24 }}
      className="flex flex-col gap-3"
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-amber-300 via-orange-400 to-fuchsia-400 shadow-md shadow-amber-500/20">
          <span className="text-sm font-bold text-stone-900">N</span>
        </div>
        <div className="min-w-0 max-w-[92%] sm:max-w-[80%]">
          <div className="glass markdown-body rounded-3xl rounded-tl-lg px-5 py-4 text-[15px] text-foreground/90">
            <ReactMarkdown>{message.content}</ReactMarkdown>
          </div>
        </div>
      </div>

      {message.sources && message.sources.length > 0 && (
        <div className="ml-12">
          <p className="mb-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
            Straight from the records
          </p>
          <div className="scrollbar-thin flex gap-2.5 overflow-x-auto pb-1.5">
            {message.sources.map((s, i) => (
              <SourceCard key={`${s.id}-${i}`} source={s} index={i} />
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/* Thread                                                              */
/* ------------------------------------------------------------------ */

interface ThreadProps {
  messages: ChatMessage[];
  thinking: boolean;
  question: string;
  onQuestionChange: (v: string) => void;
  onAsk: (q: string) => void;
  error: string | null;
  onRetry: () => void;
}

export function Thread({
  messages,
  thinking,
  question,
  onQuestionChange,
  onAsk,
  error,
  onRetry,
}: ThreadProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, thinking, error]);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {/* Messages */}
      <div className="scrollbar-thin flex-1 overflow-y-auto px-4 pb-6 pt-24 sm:px-6 lg:px-8">
        <div className="mx-auto flex max-w-3xl flex-col gap-7">
          {messages.map((m) => (
            <MessageBubble key={m.id} message={m} />
          ))}

          <AnimatePresence>{thinking && <ThinkingBubble />}</AnimatePresence>

          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="glass flex items-center justify-between gap-3 rounded-2xl border-red-400/30 px-4 py-3"
              >
                <p className="text-sm text-red-300">{error}</p>
                <button
                  onClick={onRetry}
                  className="flex shrink-0 items-center gap-1.5 rounded-xl bg-red-400/10 px-3 py-1.5 text-xs font-medium text-red-300 transition-colors hover:bg-red-400/20"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  Retry
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          <div ref={bottomRef} />
        </div>
      </div>

      {/* Docked composer */}
      <div className="px-4 pb-5 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl">
          <Composer
            value={question}
            onChange={onQuestionChange}
            onSubmit={() => onAsk(question)}
            busy={thinking}
            variant="docked"
            placeholder="Ask a follow-up…"
          />
          <p className="mt-2.5 text-center text-[11px] text-muted-foreground">
            Answers come from the official Nobel dataset — Ask Nobel can occasionally mix up details.
          </p>
        </div>
      </div>
    </div>
  );
}
