export interface NobelRecord {
  id: number;
  name: string;
  gender: string; // Male | Female | Organization
  indOrOrg: string; // Individual | Organization
  year: number;
  category: string;
  categoryFullName: string | null;
  portion: string; // 1/1 | 1/2 | 1/3
  prizeAmount: number | null;
  prizeAmountAdjusted: number | null;
  dateAwarded: string | null;
  motivation: string;
  birthYear: number | null;
  birthCountry: string | null;
  birthCity: string | null;
  birthContinent: string | null;
  deathYear: number | null;
  affiliation: string | null;
  affiliationCountry: string | null;
  affiliationCity: string | null;
  age: number | null;
  decade: number;
  laureateUrl: string;
}

export interface Kpis {
  totalLaureates: number;
  totalPrizeRecords: number;
  femaleLaureates: number;
  femaleShare: number;
  orgLaureates: number;
  countries: number;
  avgAge: number;
  youngest: number;
  oldest: number;
  yearMin: number;
  yearMax: number;
  categories: string[];
  repeatLaureates: number;
}

export interface YearPoint { year: number; laureates: number }
export interface CategorySplit {
  category: string; short: string; total: number;
  Male: number; Female: number; Organization: number;
}
export interface AgeByCategory {
  category: string; mean: number; median: number; min: number; max: number; count: number;
}
export interface AgeByDecade { decade: string; mean: number; median: number; n: number }
export interface HeatmapData {
  countries: string[];
  categories?: string[];
  decades?: string[];
  matrix: number[][];
  rowTotals?: number[];
}
export interface Institution { name: string; count: number }
export interface ShareByDecade {
  decade: string; full: number; half: number; third: number; quarter: number; total: number;
}
export interface MigrationByDecade {
  decade: string; domestic: number; migrant: number; migrantPct: number;
}
export interface TopFlow { from: string; to: string; count: number }
export interface FemaleByDecade {
  decade: string; female: number; male: number; org: number; total: number; femalePct: number;
}
export interface FunFactWinner {
  name: string; age: number; year: number; category: string;
}
export interface FunFacts {
  youngest: FunFactWinner[];
  oldest: FunFactWinner[];
  topFlow: TopFlow | null;
  topInstitution: { name: string; count: number } | null;
}

export interface NobelData {
  kpis: Kpis;
  byYear: YearPoint[];
  byCategory: CategorySplit[];
  ageByCategory: AgeByCategory[];
  ageByDecade: AgeByDecade[];
  countryByCategory: HeatmapData;
  countryByDecade: HeatmapData;
  topInstitutions: Institution[];
  shareByDecade: ShareByDecade[];
  migrationByDecade: MigrationByDecade[];
  topFlows: TopFlow[];
  femaleByDecade: FemaleByDecade[];
  funFacts: FunFacts;
  records: NobelRecord[];
}

// Category palette (warm, no blue/indigo)
export const CATEGORY_COLORS: Record<string, string> = {
  Physics: "#f59e0b",
  Chemistry: "#2dd4bf",
  "Physiology or Medicine": "#fb7185",
  Literature: "#c4b5fd",
  Peace: "#a3e635",
  "Economic Sciences": "#f0abfc",
};

export const catColor = (c: string) => CATEGORY_COLORS[c] ?? "#d6d3d1";
export const catShort = (c: string) =>
  c === "Physiology or Medicine" ? "Medicine" : c === "Economic Sciences" ? "Economics" : c;

export const GENDER_COLORS: Record<string, string> = {
  Male: "#fbbf24",
  Female: "#fb7185",
  Organization: "#a8a29e",
};

export const SHARE_COLORS: Record<string, string> = {
  full: "#fbbf24",
  half: "#d97706",
  third: "#a8a29e",
  quarter: "#57534e",
};
