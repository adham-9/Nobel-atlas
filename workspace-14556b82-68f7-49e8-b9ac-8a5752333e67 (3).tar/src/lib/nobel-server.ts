import nobelData from "@/data/nobel.json";
import type { NobelData, NobelRecord } from "./nobel";

const data = nobelData as unknown as NobelData;
const records = data.records;

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export interface SourceRecord {
  id: number;
  name: string;
  year: number;
  category: string;
  gender: string;
  age: number | null;
  birthCountry: string | null;
  motivation: string;
}

export interface RetrievedContext {
  factLines: string[];
  sourceCandidates: SourceRecord[];
}

/* ------------------------------------------------------------------ */
/* Precomputed indexes                                                 */
/* ------------------------------------------------------------------ */

const CATEGORIES = data.kpis.categories;

const CATEGORY_SYNONYMS: Record<string, string> = {
  medicine: "Physiology or Medicine",
  medical: "Physiology or Medicine",
  physiology: "Physiology or Medicine",
  economics: "Economic Sciences",
  economy: "Economic Sciences",
  economic: "Economic Sciences",
  literature: "Literature",
  literary: "Literature",
  peace: "Peace",
  physics: "Physics",
  chemistry: "Chemistry",
  math: "none", // no Nobel in math -> keep away from Physics
};

const COUNTRY_ALIASES: Record<string, string[]> = {
  usa: ["united states", "usa", "america", "american", "u s"],
  uk: ["united kingdom", "britain", "british", "england", "scotland", "wales", "u k"],
  germany: ["germany", "german"],
  france: ["france", "french"],
  japan: ["japan", "japanese"],
  russia: ["russia", "russian", "soviet"],
  china: ["china", "chinese"],
  india: ["india", "indian"],
  italy: ["italy", "italian"],
  sweden: ["sweden", "swedish"],
  switzerland: ["switzerland", "swiss"],
  austria: ["austria", "austrian"],
  netherlands: ["netherlands", "dutch"],
};

const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "of", "in", "on", "at", "to", "for", "with",
  "was", "were", "is", "are", "did", "do", "does", "who", "what", "when",
  "where", "which", "how", "why", "many", "much", "has", "have", "had",
  "won", "win", "get", "got", "get", "their", "they", "them", "from",
  "about", "ever", "all", "any", "can", "you", "tell", "me", "please",
  "first", "most", "more", "than", "that", "this", "there", "his", "her",
  "not", "but", "by", "as", "be", "been", "it", "its", "into", "also",
  "some", "list", "show", "give", "name", "names", "prize", "prizes",
  "nobel", "laureate", "laureates", "country", "countries", "nation",
  "national", "world", "people", "person", "man", "woman", "women",
  "number", "much",
]);

const allCountries = Array.from(
  new Set(records.map((r) => r.birthCountry).filter((c): c is string => !!c))
);

function matchCountries(q: string): string[] {
  const ql = q.toLowerCase();
  const found: string[] = [];
  for (const country of allCountries) {
    if (ql.includes(country.toLowerCase())) found.push(country);
  }
  for (const canonical of Object.keys(COUNTRY_ALIASES)) {
    for (const alias of COUNTRY_ALIASES[canonical]) {
      const re = new RegExp(`\\b${alias}\\b`, "i");
      if (re.test(ql)) {
        const real = allCountries.find(
          (c) => c.toLowerCase() === canonical || c.toLowerCase().includes(canonical)
        );
        if (real && !found.includes(real)) found.push(real);
        break;
      }
    }
  }
  return found;
}

function matchCategories(q: string): string[] {
  const ql = q.toLowerCase();
  const found: string[] = [];
  for (const cat of CATEGORIES) {
    if (ql.includes(cat.toLowerCase())) found.push(cat);
  }
  for (const [syn, cat] of Object.entries(CATEGORY_SYNONYMS)) {
    if (cat === "none") continue;
    const re = new RegExp(`\\b${syn}\\b`, "i");
    if (re.test(ql) && !found.includes(cat)) found.push(cat);
  }
  return found;
}

function matchYears(q: string): number[] {
  const years: number[] = [];
  const re = /\b(18|19|20)\d{2}\b/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(q)) !== null) {
    const y = parseInt(m[0], 10);
    if (y >= data.kpis.yearMin && y <= data.kpis.yearMax) years.push(y);
  }
  return [...new Set(years)];
}

function matchDecade(q: string): number | null {
  const m = q.match(/\b(18|19|20)\d0s\b/);
  if (m) return parseInt(m[0].replace("s", ""), 10);
  return null;
}

function tokenize(q: string): string[] {
  return q
    .toLowerCase()
    .replace(/[^a-z0-9\s']/g, " ")
    .split(/\s+/)
    .filter((t) => t.length >= 3 && !STOPWORDS.has(t));
}

/* ------------------------------------------------------------------ */
/* Record scoring                                                      */
/* ------------------------------------------------------------------ */

function scoreRecord(r: NobelRecord, tokens: string[]): number {
  let score = 0;
  const name = r.name.toLowerCase();
  const country = (r.birthCountry ?? "").toLowerCase();
  const city = (r.birthCity ?? "").toLowerCase();
  const category = r.category.toLowerCase();
  const motivation = r.motivation.toLowerCase();
  const affiliation = (r.affiliation ?? "").toLowerCase();

  for (const t of tokens) {
    if (name.includes(t)) score += 6;
    if (country === t) score += 4;
    else if (country.includes(t)) score += 3;
    if (city.includes(t)) score += 2;
    if (category.includes(t)) score += 2;
    if (affiliation.includes(t)) score += 2;
    if (motivation.includes(t)) score += 1;
  }
  return score;
}

function toSource(r: NobelRecord): SourceRecord {
  return {
    id: r.id,
    name: r.name,
    year: r.year,
    category: r.category,
    gender: r.gender,
    age: r.age,
    birthCountry: r.birthCountry,
    motivation:
      r.motivation.length > 220 ? r.motivation.slice(0, 217) + "..." : r.motivation,
  };
}

function dedupe(records: NobelRecord[]): NobelRecord[] {
  const seen = new Set<number>();
  return records.filter((r) => {
    if (seen.has(r.id)) return false;
    seen.add(r.id);
    return true;
  });
}

/* ------------------------------------------------------------------ */
/* Computed facts                                                      */
/* ------------------------------------------------------------------ */

function repeatWinners(): { name: string; wins: { year: number; category: string }[] }[] {
  const byName = new Map<string, { year: number; category: string }[]>();
  for (const r of records) {
    const key = r.name.trim();
    const arr = byName.get(key) ?? [];
    arr.push({ year: r.year, category: r.category });
    byName.set(key, arr);
  }
  return Array.from(byName.entries())
    .filter(([, wins]) => wins.length > 1)
    .map(([name, wins]) => ({ name, wins: wins.sort((a, b) => a.year - b.year) }));
}

function computeFacts(q: string): { facts: string[]; extra: NobelRecord[] } {
  const facts: string[] = [];
  const extra: NobelRecord[] = [];
  const ql = q.toLowerCase();

  // Always-on baseline
  const k = data.kpis;
  facts.push(
    `Overview: ${k.totalLaureates} distinct laureates, ${k.totalPrizeRecords} prize records, ${k.femaleLaureates} female laureates (${k.femaleShare}%), ${k.orgLaureates} organizations, ${k.countries} birth countries, years ${k.yearMin}-${k.yearMax}, average age at prize ${k.avgAge}, repeat winners: ${k.repeatLaureates}.`
  );
  facts.push(
    "Prizes by category: " +
      data.byCategory.map((c) => `${c.category}=${c.total}`).join(", ") + "."
  );
  facts.push(
    "Top institutions: " +
      data.topInstitutions.slice(0, 6).map((i) => `${i.name}=${i.count}`).join(", ") + "."
  );

  // Country ranking (always available so "which country..." has a precise answer)
  const countryCounts = new Map();
  const seenNames = new Set();
  for (const r of records) {
    if (!r.birthCountry) continue;
    const key = r.birthCountry;
    const nameKey = r.name.trim();
    const dedupeKey = `${key}::${nameKey}`;
    if (seenNames.has(dedupeKey)) continue;
    seenNames.add(dedupeKey);
    countryCounts.set(key, (countryCounts.get(key) ?? 0) + 1);
  }
  const topCountries = Array.from(countryCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 12);
  facts.push(
    "Top countries by distinct laureates: " +
      topCountries.map(([c, n]) => `${c}=${n}`).join(", ") + "."
  );

  const categories = matchCategories(q);
  const years = matchYears(q);
  const countries = matchCountries(q);
  const decade = matchDecade(q);

  // Superlative intents
  const wantsYoungest = /\byoungest\b/.test(ql);
  const wantsOldest = /\boldest\b/.test(ql);
  const wantsFirst = /\bfirst\b/.test(ql);
  const wantsLast = /\b(last|latest|most recent)\b/.test(ql);
  const wantsWomen = /\b(woman|women|female|she|her)\b/.test(ql);
  const wantsRepeat = /\b(twice|two times|multiple|more than once|again|second)\b/.test(ql);

  let pool = records;

  if (categories.length > 0) {
    pool = pool.filter((r) => categories.includes(r.category));
    facts.push(`Filtered to category: ${categories.join(", ")}.`);
  }

  if (wantsRepeat) {
    const reps = repeatWinners();
    facts.push(
      "Repeat winners: " +
        reps.map((r) => `${r.name} (${r.wins.map((w) => `${w.category} ${w.year}`).join(" & ")})`).join("; ") + "."
    );
    for (const rep of reps.slice(0, 6)) {
      const rec = records.find((r) => r.name === rep.name);
      if (rec) extra.push(rec);
    }
  }

  if (wantsYoungest) {
    const sorted = [...pool].filter((r) => r.age != null).sort((a, b) => (a.age! - b.age!));
    facts.push(
      "Youngest laureates" + (categories.length ? ` in ${categories.join("/")}` : "") + ": " +
        sorted.slice(0, 5).map((r) => `${r.name} won ${r.category} ${r.year} at age ${r.age}`).join("; ") + "."
    );
    extra.push(...sorted.slice(0, 5));
  }
  if (wantsOldest) {
    const sorted = [...pool].filter((r) => r.age != null).sort((a, b) => (b.age! - a.age!));
    facts.push(
      "Oldest laureates" + (categories.length ? ` in ${categories.join("/")}` : "") + ": " +
        sorted.slice(0, 5).map((r) => `${r.name} won ${r.category} ${r.year} at age ${r.age}`).join("; ") + "."
    );
    extra.push(...sorted.slice(0, 5));
  }
  if (wantsFirst && categories.length > 0) {
    const sorted = [...pool].sort((a, b) => a.year - b.year);
    facts.push(`Earliest prizes in ${categories.join("/")}: ` +
      sorted.slice(0, 5).map((r) => `${r.name} (${r.year})`).join("; ") + ".");
    extra.push(...sorted.slice(0, 3));
  }
  if (wantsFirst && wantsWomen) {
    const sorted = [...pool].filter((r) => r.gender === "Female").sort((a, b) => a.year - b.year);
    if (sorted.length > 0) {
      facts.push(`First women laureates: ` +
        sorted.slice(0, 5).map((r) => `${r.name} won ${r.category} in ${r.year}`).join("; ") + ".");
      extra.push(...sorted.slice(0, 5));
    }
  }
  if (wantsLast && categories.length > 0) {
    const sorted = [...pool].sort((a, b) => b.year - a.year);
    facts.push(`Most recent prizes in ${categories.join("/")}: ` +
      sorted.slice(0, 5).map((r) => `${r.name} (${r.year})`).join("; ") + ".");
    extra.push(...sorted.slice(0, 3));
  }

  if (wantsWomen) {
    facts.push(
      "Female laureates by decade: " +
        data.femaleByDecade.map((d) => `${d.decade}:${d.femalePct}%`).join(", ") + "."
    );
    if (categories.length > 0) {
      const split = data.byCategory.find((c) => categories.includes(c.category));
      if (split) {
        facts.push(`In ${split.category}: ${split.total} total prizes, Female=${split.Female}, Male=${split.Male}, Organization=${split.Organization}.`);
      }
    }
  }

  if (years.length > 0) {
    for (const y of years.slice(0, 3)) {
      const yr = records.filter((r) => r.year === y);
      facts.push(
        `Laureates of ${y}: ` +
          yr.map((r) => `${r.name} (${r.category})`).join("; ") + "."
      );
      extra.push(...yr.slice(0, 12));
    }
  }

  if (decade !== null) {
    const dec = data.byYear.filter((y) => y.year >= decade && y.year < decade + 10);
    const total = dec.reduce((s, y) => s + y.laureates, 0);
    facts.push(`During the ${decade}s, ${total} prize records were awarded.`)
    const femaleDec = data.femaleByDecade.find((d) => d.decade === `${decade}s`);
    if (femaleDec) {
      facts.push(`${decade}s gender split: female=${femaleDec.female}, male=${femaleDec.male}, organizations=${femaleDec.org}, female share=${femaleDec.femalePct}%.`);
    }
  }

  if (countries.length > 0) {
    for (const c of countries.slice(0, 2)) {
      const cr = records.filter((r) => r.birthCountry === c);
      const byCat = new Map<string, number>();
      for (const r of cr) byCat.set(r.category, (byCat.get(r.category) ?? 0) + 1);
      const sortedCats = Array.from(byCat.entries()).sort((a, b) => b[1] - a[1]);
      const topYears = [...cr].sort((a, b) => a.year - b.year);
      facts.push(
        `${c}: ${cr.length} prize records. By category: ${sortedCats.map(([cat, n]) => `${cat}=${n}`).join(", ")}. Earliest: ${topYears[0]?.name} (${topYears[0]?.year}). Most recent: ${topYears[topYears.length - 1]?.name} (${topYears[topYears.length - 1]?.year}).`
      );
      // top 6 most recent famous names from that country
      extra.push(...[...cr].sort((a, b) => b.year - a.year).slice(0, 6));
    }
  }

  // Age questions
  if (/\bage\b/.test(ql) && categories.length > 0) {
    const abc = data.ageByCategory.filter((a) => categories.includes(a.category));
    for (const a of abc) {
      facts.push(`${a.category}: mean age ${a.mean}, median ${a.median}, range ${a.min}-${a.max} (${a.count} laureates).`);
    }
  }
  if (/\bage\b/.test(ql) && categories.length === 0) {
    facts.push(
      "Mean age by category: " +
        data.ageByCategory.map((a) => `${a.category}=${a.mean}`).join(", ") + "."
    );
    facts.push(
      "Mean age by decade: " +
        data.ageByDecade.map((a) => `${a.decade}=${a.mean}`).join(", ") + "."
    );
  }

  // Prize money questions
  if (/\b(money|amount|cash|worth|richest|largest)\b/.test(ql)) {
    const withAmount = records.filter((r) => r.prizeAmountAdjusted != null);
    const top = [...withAmount].sort((a, b) => b.prizeAmountAdjusted! - a.prizeAmountAdjusted!).slice(0, 5);
    facts.push(
      "Largest adjusted prize amounts: " +
        top.map((r) => `${r.name} ${r.year} ${r.category}: ${r.prizeAmountAdjusted} SEK adjusted`).join("; ") + "."
    );
    extra.push(...top.slice(0, 3));
  }

  // Share questions
  if (/\b(share|shared|split|half|third|quarter|portion)\b/.test(ql)) {
    facts.push(
      "Prize sharing over decades: " +
        data.shareByDecade.map((s) => `${s.decade}: full=${s.full}, shared=${s.half + s.third + s.quarter}`).join("; ") + "."
    );
  }

  // Migration / brain drain
  if (/\b(migrant|migration|move|moved|brain drain|abroad|emigrated)\b/.test(ql)) {
    facts.push(
      "Migration by decade (laureates working outside birth country): " +
        data.migrationByDecade.map((m) => `${m.decade}=${m.migrantPct}%`).join(", ") + "."
    );
    facts.push(
      data.topFlows.slice(0, 5)
        .map((f) => `Top flow: ${f.from} -> ${f.to}: ${f.count} laureates`).join("; ") + "."
    );
  }

  // Continent questions
  if (/\b(africa|african|south america|latin america|asia|asian|oceania|australia)\b/.test(ql)) {
    const continentMap = new Map<string, number>();
    for (const r of records) {
      if (r.birthContinent) continentMap.set(r.birthContinent, (continentMap.get(r.birthContinent) ?? 0) + 1);
    }
    facts.push(
      "Laureates by birth continent: " +
        Array.from(continentMap.entries()).sort((a, b) => b[1] - a[1]).map(([c, n]) => `${c}=${n}`).join(", ") + "."
    );
  }

  // Gap years (wars)
  if (/\b(war|wars|world war|gap|stopped|cancelled|not awarded)\b/.test(ql)) {
    const zeroYears = data.byYear.filter((y) => y.laureates === 0).map((y) => y.year);
    facts.push(`Years with no prizes awarded: ${zeroYears.join(", ")}.`);
  }

  return { facts, extra };
}

/* ------------------------------------------------------------------ */
/* Main retrieval                                                      */
/* ------------------------------------------------------------------ */

export function buildContext(question: string): RetrievedContext {
  const { facts, extra } = computeFacts(question);

  const tokens = tokenize(question);
  const scored = records
    .map((r) => ({ r, s: scoreRecord(r, tokens) }))
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s)
    .slice(0, 20)
    .map((x) => x.r);

  const merged = dedupe([...extra, ...scored]).slice(0, 22);

  const sourceCandidates = merged.map(toSource);

  const recordLines = merged.map(
    (r) =>
      `[R${r.id}] ${r.name} | ${r.category} ${r.year} | ${r.gender}` +
      (r.age != null ? ` | age ${r.age}` : "") +
      (r.birthCountry ? ` | born in ${r.birthCountry}` : "") +
      (r.birthCity ? `, ${r.birthCity}` : "") +
      (r.affiliation ? ` | ${r.affiliation}` : "") +
      ` | motivation: ${r.motivation.slice(0, 200)}`
  );

  const factLines = [
    ...facts,
    ...(recordLines.length
      ? ["Relevant laureate records (use ids in CITED):", ...recordLines]
      : []),
  ];

  return { factLines, sourceCandidates };
}

export const NOBEL_KPI_SUMMARY = `Dataset covers ${data.kpis.yearMin}-${data.kpis.yearMax}.`;
